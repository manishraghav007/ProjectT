package com.feing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.feing.entity.Lease;
import com.feing.intf.LeaseFiengClient;

@RestController
@RequestMapping("/leas")
public class LeaseFiengController {

	@Autowired
	private LeaseFiengClient leaseService;
	
	@PostMapping("/add")
	public String addLease(@RequestBody Lease lease) {
		return leaseService.addLease(lease);
	}
	
	@GetMapping("/getbyid/{id}")
	public Lease getLeaseById(@PathVariable Long id) {
		return leaseService.getLeaseById(id);
	}
	
	@GetMapping("/getall")
	public List<Lease> getAllLeases(){
		return leaseService.getAllLeases();
	}
	
	@DeleteMapping("/{id}")
	public void deleteLease(@PathVariable Long id) {
		 leaseService.deleteLease(id);
	}
}
