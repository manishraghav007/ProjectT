package com.feing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.feing.entity.Manager;
import com.feing.entity.Property;
import com.feing.intf.ManagerFiengClient;
import com.feing.intf.PropertyFiengClient;

@RestController
@RequestMapping("/manage")
public class ManagerFeingController {

    @Autowired
    private ManagerFiengClient managerService;
    
    @Autowired
    private PropertyFiengClient propertyService;

    // Create a new manager
    @PostMapping
    public ResponseEntity<Manager> createManager(@RequestBody Manager manager) {
        ResponseEntity<Manager> savedManager = managerService.createManager(manager);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedManager.getBody());
    }

    // Get all managers
    @GetMapping
    public List<Manager> getAllManagers() {
        return managerService.getAllManagers();
    }

    // Get manager by ID
    @GetMapping("/{id}")
    public ResponseEntity<Manager> getManagerById(@PathVariable Long id) {
        ResponseEntity<Manager> managerResponse = managerService.getManagerById(id);
        if (managerResponse.getBody() == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(managerResponse.getBody());
    }

    // Delete a manager by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteManagerById(@PathVariable Long id) {
        managerService.deleteManagerById(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }

    // Add a property to a manager
    @PostMapping("/{managerId}/properties")
    public ResponseEntity<Property> addPropertiesToManager(
            @PathVariable Long managerId,
            @RequestBody Property property) {
        
        // Get the manager by ID
        ResponseEntity<Manager> managerResponse = managerService.getManagerById(managerId);
        
        // If the manager doesn't exist, return an error
        if (managerResponse.getBody() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        
        // Set the manager's ID in the property object
        property.setManagerId(managerResponse.getBody().getId());
        
        // Save the property using the addProperty method from PropertyFiengClient
        try {
            ResponseEntity<Property> savedPropertyResponse = propertyService.addProperty(property);
            if (savedPropertyResponse.getStatusCode().is2xxSuccessful()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(savedPropertyResponse.getBody());
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);  // Handle failed response
            }
        } catch (Exception e) {
            // Handle exception (e.g., connection issues)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
