package com.feing.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.feing.entity.Property;
import com.feing.entity.Manager;
import com.feing.intf.ManagerFiengClient;
import com.feing.intf.PropertyFiengClient;

@RestController
@RequestMapping("/prop")
public class PropertyFiengController {

    @Autowired 
    private PropertyFiengClient propertyService;
    
    @Autowired
    private ManagerFiengClient managerService;
    
    // Add a new property
    @PostMapping("/add")
    public ResponseEntity<Property> addProperty(@RequestBody Property property) {
        // Get the manager by its ID from the Manager service
        ResponseEntity<Manager> managerResponse = managerService.getManagerById(property.getManagerId());

        // Check if manager exists
        if (managerResponse != null && managerResponse.getBody() != null) {
            // Get the Manager object (you don't need to set it directly on the Property object)
            Manager manager = managerResponse.getBody();

            // Optionally, if you want to check that the manager's ID matches the property managerId (for integrity)
            if (!manager.getId().equals(property.getManagerId())) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // In case IDs do not match
            }

            // Now call the Property service to save the property (the property already has the managerId)
            ResponseEntity<Property> savedPropertyResponse = propertyService.addProperty(property);

            // Return the response with the saved property
            return ResponseEntity.status(HttpStatus.CREATED).body(savedPropertyResponse.getBody());
        } else {
            // Return a bad request if manager does not exist
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }

    // Get properties by city
    @GetMapping("/city/{city}")
    public List<Property> getPropertiesByCity(@PathVariable String city) {
        return propertyService.getPropertiesByCity(city);
    }

    // Get all properties
    @GetMapping("/all")
    public List<Property> getAllProperties() {
        return propertyService.getAllProperties();
    }

    // Update a property
    @PutMapping("/update")
    public ResponseEntity<String> updateProperty(@RequestBody Property property) {
        ResponseEntity<String> updateResult = propertyService.updateProperty(property);
        return ResponseEntity.status(HttpStatus.OK).body(updateResult.getBody());
    }

    // Get properties by rent
    @GetMapping("/rent/{rent}")
    public List<Property> getPropertiesByRent(@PathVariable double rent) {
        return propertyService.getPropertiesByRent(rent);
    }

    // Delete a property by ID
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteProperty(@PathVariable Long id) {
        ResponseEntity<String> deleteResponse = propertyService.deleteProperty(id);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body(deleteResponse.getBody());
    }
}
