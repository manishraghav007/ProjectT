package com.feing.entity;

import java.util.List;

public class Manager {

    private Long id;
    private String name;
    private List<Property> propertyIds; // Assuming you want to expose only property IDs

    // Default constructor
    public Manager() {}

    // Constructor with parameters
    public Manager(Long id, String name, List<Property> propertyIds) {
        this.id = id;
        this.name = name;
        this.propertyIds = propertyIds;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Property> getPropertyIds() {
        return propertyIds;
    }

    public void setPropertyIds(List<Property> propertyIds) {
        this.propertyIds = propertyIds;
    }
}