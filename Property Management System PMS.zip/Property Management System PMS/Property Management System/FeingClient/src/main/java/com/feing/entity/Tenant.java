package com.feing.entity;

public class Tenant {
	private long id;
	private String name;
	private String email;
	private long Phone;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return Phone;
	}
	public void setPhone(long phone) {
		Phone = phone;
	}
	public Tenant(long id, String name, String email, long phone) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		Phone = phone;
	}
	public Tenant() {
		super();
	}
	
	
}
