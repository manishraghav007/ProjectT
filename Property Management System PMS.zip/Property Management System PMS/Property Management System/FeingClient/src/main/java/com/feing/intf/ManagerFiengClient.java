package com.feing.intf;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.feing.entity.Manager;
import com.feing.entity.Property;

@FeignClient(name="FeignClientManager", url="http://localhost:8082/managers")
public interface ManagerFiengClient {
	 @PostMapping
	   public ResponseEntity<Manager> createManager(@RequestBody Manager manager) ;

	   // Get all managers
	   @GetMapping
	   public List<Manager> getAllManagers() ;

	   // Get manager by ID
	   @GetMapping("/{id}")
	   public ResponseEntity<Manager> getManagerById(@PathVariable Long id) ;
	   // Delete a manager by ID
	   @DeleteMapping("/{id}")
	   public ResponseEntity<Void> deleteManagerById(@PathVariable Long id);

	   // Add a property to a manager
	   @PostMapping("/{managerId}/properties")
	   public ResponseEntity<Property> addPropertiesToManager(
	           @PathVariable Long managerId,
	           @RequestBody Property property) ;
}
