package com.feing.intf;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.feing.entity.Property;


@FeignClient(name="FeignClientProperty", url="http://localhost:8082/properties")
public interface PropertyFiengClient {
	@PostMapping("/add")
	   public ResponseEntity<Property> addProperty(@RequestBody Property property) ;

	   // Get properties by city
	   @GetMapping("/city/{city}")
	   public List<Property> getPropertiesByCity(@PathVariable String city) ;

	   // Get all properties
	   @GetMapping("/all")
	   public List<Property> getAllProperties() ;

	   // Update a property
	   @PutMapping("/update")
	   public ResponseEntity<String> updateProperty(@RequestBody Property property) ;

	   // Get properties by rent
	   @GetMapping("/rent/{rent}")
	   public List<Property> getPropertiesByRent(@PathVariable double rent);

	   // Delete a property by ID
	   @DeleteMapping("/{id}")
	   public ResponseEntity<String> deleteProperty(@PathVariable Long id) ;
}
