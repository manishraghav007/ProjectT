package com.feing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeingClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
