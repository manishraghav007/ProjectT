package com.property.administration.controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.property.administration.entity.Admin;
import com.property.administration.exception.InvalidAdminDataException;
import com.property.administration.exception.ResourceNotFoundException;
import com.property.administration.service.AdminServiceImpl;
import com.property.manager.entity.Manager;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin")
@Validated
public class AdminController {

    @Autowired
    private AdminServiceImpl adminService;

    @PostMapping("/add")
    public String save(@RequestBody @Valid Admin admin) {
    	 try {
             return adminService.save(admin);
         } catch (InvalidAdminDataException e) {
             throw new InvalidAdminDataException("Admin data is invalid: " + e.getMessage());
         }
    	 
    }

    @GetMapping("/getall")
    public List<Admin> getAllAdmins() {
    	return Optional.ofNullable(adminService.getAll()).orElse(Collections.emptyList());
    }

    @GetMapping("/{id}")
    public Admin getAdminById(@PathVariable Long id) {
    	Admin admin = adminService.getById(id);
        if (admin == null) {
            throw new ResourceNotFoundException("Admin with ID " + id + " not found.");
        }
        return admin;
   }

    @DeleteMapping("/{id}")
    public String deleteAdmin(@PathVariable Long id) {
    	if (!adminService.existsById(id)) {
            throw new ResourceNotFoundException("Admin with ID " + id + " not found.");
        }
        adminService.deleteById(id);
        return "Record of "+id+" is deleted";
    }
    
    @PostMapping("/{adminId}/addManager")
    public String addManagerToAdmin(@PathVariable Long adminId, @RequestBody Manager manager) {
        try {
            Admin admin = adminService.getById(adminId);
            admin.getManagerIds().add(manager.getId());
            adminService.save(admin);
            return "Manager successfully added to admin!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error" + e.getMessage();
        }
    }
}
