package com.property.administration.exception;

public class AdminNotFoundException {

}
