package com.property.administration.exception;

public class InvalidAdminDataException extends RuntimeException{
	 public InvalidAdminDataException(String message) {
	        super(message);
	    }
}
