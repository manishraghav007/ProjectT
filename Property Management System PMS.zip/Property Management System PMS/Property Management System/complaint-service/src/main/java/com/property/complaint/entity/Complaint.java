package com.property.complaint.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique ID for the complaint
    
    @NotBlank(message = "Description cannot be blank") 
    @Size(max = 500, message = "Description must be at most 500 characters")
    private String description; // Description of the complaint
    
    @NotBlank(message = "Status cannot be blank") 
    @Size(max = 20, message = "Status must be at most 20 characters")
    private String status; // Status (e.g., Pending, Resolved)
    
    @NotNull(message = "Tenant ID cannot be null")
    private Long tenantId; // Reference to the Tenant's ID (no association mapping)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getTenantId() {
		return tenantId;
	}
	public void setTenantId(Long tenantId) {
		this.tenantId = tenantId;
	}
	public Complaint() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Complaint(Long id, String description, String status, Long tenantId) {
		super();
		this.id = id;
		this.description = description;
		this.status = status;
		this.tenantId = tenantId;
	}
    
}
