// ComplaintRepository.java
package com.property.complaint.repository;

import com.property.complaint.entity.Complaint;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

    // Custom query to find complaints by tenantId
	List<Complaint> findByTenantId(Long tenantId);
}
