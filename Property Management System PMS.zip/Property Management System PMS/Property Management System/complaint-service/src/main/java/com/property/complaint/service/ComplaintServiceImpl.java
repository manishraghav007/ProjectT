// ComplaintService.java
package com.property.complaint.service;

import com.property.complaint.entity.Complaint;
import com.property.complaint.repository.ComplaintRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

@Repository
public class ComplaintServiceImpl implements ComplaintServiceIntf {

    @Autowired
    private ComplaintRepository complaintRepository;

    
    public Complaint saveComplaint(Complaint complaint) {
        return complaintRepository.save(complaint); // Save complaint to database
    }

    
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll(); // Get all complaints
    }

    
    public List<Complaint> getComplaintsByTenantId(Long tenantId) {
        return complaintRepository.findByTenantId(tenantId); // Get complaints by tenantId
    }

    
    public Complaint getComplaintById(Long id) {
        return complaintRepository.findById(id).orElse(null); // Get complaint by ID
    }

    
    public void deleteComplaint(Long id) {
        complaintRepository.deleteById(id); // Delete complaint by ID
    }
    
    public boolean existsById(Long id) {
        return complaintRepository.existsById(id);
    }
}
