package com.property.lease.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.property.lease.entity.Lease;
import com.property.lease.exception.ResourceNotFoundException;
import com.property.lease.repository.LeaseRepository;


@Repository
public class LeaseServiceImpl implements LeaseServiceIntf {

    @Autowired
   private LeaseRepository leaseRepository;
	@Override
	public String save(Lease lease) {
		// TODO Auto-generated method stub
		 leaseRepository.save(lease);
		 return "Lease details added";
	}

	@Override
	public Lease findById(Long id) {
		return leaseRepository.findById(id)
	            .orElseThrow(() -> new ResourceNotFoundException("Lease with ID " + id + " not found."));
	}

	@Override
	public List<Lease> findAll() {
		// TODO Auto-generated method stub
		return leaseRepository.findAll();
	}

	@Override
	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		 leaseRepository.deleteById(id);
		
	}
}
