package com.property.lease.Service;

import java.util.List;

import com.property.lease.entity.Lease;

public interface LeaseServiceIntf {

	String save(Lease lease);

	Lease findById(Long id);

	List<Lease> findAll();

	void deleteById(Long id);
}
