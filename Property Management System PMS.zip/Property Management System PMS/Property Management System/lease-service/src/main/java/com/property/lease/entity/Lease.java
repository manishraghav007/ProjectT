package com.property.lease.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Positive;

@Entity
public class Lease {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotNull(message = "Tenant ID cannot be null")
	@Positive(message = "Tenant ID must be a positive number")
	private long tenantId;

	@NotNull(message = "Property ID cannot be null")
	@Positive(message = "Property ID must be a positive number")
	private long propertyId;
	@NotNull(message = "Start date cannot be null")
	@PastOrPresent(message = "Start date cannot be in the future")
	private LocalDate startDate;

	@NotNull(message = "End date cannot be null")
	@FutureOrPresent(message = "End date must be in the future or present")
	private LocalDate endDate;
	
	@NotNull(message = "Monthly rent cannot be null")
    @Positive(message = "Monthly rent must be a positive number")
	private double monthlyRent;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	public long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public double getMonthlyRent() {
		return monthlyRent;
	}

	public void setMonthlyRent(double monthlyRent) {
		this.monthlyRent = monthlyRent;
	}

}
