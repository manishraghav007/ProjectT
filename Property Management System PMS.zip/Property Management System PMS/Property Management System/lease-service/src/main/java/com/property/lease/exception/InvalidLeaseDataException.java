
package com.property.lease.exception;

public class InvalidLeaseDataException extends RuntimeException {
    public InvalidLeaseDataException(String message) {
        super(message);
    }
}
