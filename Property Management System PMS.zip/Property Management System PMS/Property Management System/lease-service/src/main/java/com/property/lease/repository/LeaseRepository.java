package com.property.lease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.property.lease.entity.Lease;

public interface LeaseRepository extends JpaRepository<Lease, Long>{

}
