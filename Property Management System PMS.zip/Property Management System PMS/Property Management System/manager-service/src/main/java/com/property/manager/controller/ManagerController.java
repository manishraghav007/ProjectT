package com.property.manager.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.property.manager.entity.Manager;
import com.property.manager.service.ManagerServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/managers")
@Validated
public class ManagerController {

   @Autowired
   private ManagerServiceImpl managerService;

   @PostMapping
   public ResponseEntity<Manager> createManager(@RequestBody @Valid Manager manager) {
       Manager savedManager = managerService.save(manager);
       return ResponseEntity.status(HttpStatus.CREATED).body(savedManager);
   }

   @GetMapping
   public List<Manager> getAllManagers() {
       return managerService.getAllManagers();
   }

   @GetMapping("/{id}")
   public ResponseEntity<Manager> getManagerById(@PathVariable Long id) {
	   Manager manager = managerService.findById(id);
       if(manager == null) {
           return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
       }
       return ResponseEntity.ok(manager);
    }
   
   @DeleteMapping("/{id}")
   public ResponseEntity<String> deleteManagerById(@PathVariable Long id) {
       boolean isDeleted = managerService.deleteById(id);
       if (isDeleted) {
           return ResponseEntity.status(HttpStatus.OK).body("Record of ID " + id + " is deleted.");
       }
       return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Deletion failed.");
   }

}
