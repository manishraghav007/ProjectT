package com.property.manager.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.property.manager.entity.Manager;
import com.property.manager.exception.ResourceNotFoundException;
import com.property.manager.repository.ManagerRepository;

@Component
public class ManagerServiceImpl implements ManagerServiceIntf {

   @Autowired
   private ManagerRepository managerRepository;

   @Override
   public Manager save(Manager manager) {
       return managerRepository.save(manager);
   }

   @Override
   public List<Manager> getAllManagers() {
       return managerRepository.findAll();
   }

   @Override
   public Manager findById(Long id) {
	   return managerRepository.findById(id)
               .orElseThrow(() -> new ResourceNotFoundException("Manager with ID " + id + " not found."));
   }
   @Override
   public boolean deleteById(Long id) {
	   if (!managerRepository.existsById(id)) {
           throw new ResourceNotFoundException("Manager with ID " + id + " not found.");
       }
       managerRepository.deleteById(id);
       return true;
   }
   @Override
   public boolean existsById(Long id) {
       return managerRepository.existsById(id);
   }
}
