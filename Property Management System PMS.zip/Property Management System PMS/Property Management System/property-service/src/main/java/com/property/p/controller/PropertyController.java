package com.property.p.controller;

import com.property.manager.exception.ResourceNotFoundException;
import com.property.p.entity.Property;
import com.property.p.service.PropertyServiceImpl;

import jakarta.validation.Valid;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/properties")
public class PropertyController {

   @Autowired
   private PropertyServiceImpl propertyService;

   @PostMapping("/add")
   public ResponseEntity<Property> addProperty(@RequestBody @Valid Property property) {
	   try {
	        Property savedProperty = propertyService.save(property);
	        return ResponseEntity.status(HttpStatus.CREATED).body(savedProperty);
	    } catch (Exception e) {
	        // Log the exception if needed
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
	    } }

   @GetMapping("/city/{city}")
   public ResponseEntity<List<Property>> getPropertiesByCity(@PathVariable String city) {
	   List<Property> properties = propertyService.getCity(city);
       if (properties.isEmpty()) {
           throw new ResourceNotFoundException("No properties found in city " + city);
       }
       return ResponseEntity.ok(properties);
    }

   @GetMapping("/all")
   public List<Property> getAllProperties() {
       return propertyService.getAll();
   }

   @PutMapping("/update")
   public ResponseEntity<String> updateProperty(@RequestBody @Valid Property property) {
	   if (property.getId() == null || !propertyService.existsById(property.getId())) {
           throw new ResourceNotFoundException("Property with ID " + property.getId() + " not found.");
       }
       String result = propertyService.updateProperty(property);
       return ResponseEntity.status(HttpStatus.OK).body(result);
   }

   @GetMapping("/rent/{rent}")
   public List<Property> getPropertiesByRent(@PathVariable double rent) {
	   List<Property> properties = propertyService.findByRent(rent);
       if (properties.isEmpty()) {
           throw new ResourceNotFoundException("No properties found with rent " + rent);
       }
       return properties;
   }

   @DeleteMapping("/delete/{id}")
   public ResponseEntity<String> deleteProperty(@PathVariable Long id) {
	   if (!propertyService.existsById(id)) {
	        throw new ResourceNotFoundException("Property with ID " + id + " does not exist. Deletion cannot proceed.");
	    }
	    propertyService.deleteById(id);
	    return ResponseEntity.status(HttpStatus.NO_CONTENT)
	                         .body("Property with ID " + id + " has been successfully deleted.");
	}
}
