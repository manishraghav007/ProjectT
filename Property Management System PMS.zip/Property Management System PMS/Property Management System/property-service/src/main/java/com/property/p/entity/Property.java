package com.property.p.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
public class Property {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Property name cannot be blank")
    @Size(max = 100, message = "Property name must be at most 100 characters")
    private String name;
    
    @NotBlank(message = "City cannot be blank")
    @Size(max = 50, message = "City must be at most 50 characters")
    private String city;
    
    @NotBlank(message = "Address cannot be blank")
    @Size(max = 200, message = "Address must be at most 200 characters")
    private String address;
    
    @Positive(message = "Rent must be a positive value")
    private double rent;

  

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }


}
