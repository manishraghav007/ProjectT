package com.property.p.service;

import com.property.manager.exception.ResourceNotFoundException;
import com.property.p.entity.Property;
import com.property.p.repository.PropertyRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PropertyServiceImpl implements PropertyServiceIntf {

   @Autowired
   private PropertyRepository propertyRepository;

   
   public Property save(Property property) {
       return propertyRepository.save(property);
   }

   public List<Property> getCity(String city) {
       return propertyRepository.findByCity(city);
   }

   public List<Property> getAll() {
       return propertyRepository.findAll();
   }

   public String updateProperty(Property property) {
       propertyRepository.save(property);
       return "Property updated successfully!";
   }

   public List<Property> findByRent(double rent) {
       return propertyRepository.findByRent(rent);
   }

   public void deleteById(Long id) {
       propertyRepository.deleteById(id);
   }

   
   public boolean existsById(Long id) {
       return propertyRepository.existsById(id);
   }
 
}
