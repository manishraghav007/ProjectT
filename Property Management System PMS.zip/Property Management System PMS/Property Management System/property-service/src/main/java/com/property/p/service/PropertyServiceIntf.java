package com.property.p.service;

import java.util.List;

import com.property.p.entity.Property;

public interface PropertyServiceIntf {

	Property save(Property property);
	List<Property> getCity(String city);
	List<Property> getAll();
	String updateProperty(Property property);
	List<Property> findByRent(double rent);
	void deleteById(Long id);
	boolean existsById(Long id);
}