package com.property.p;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
