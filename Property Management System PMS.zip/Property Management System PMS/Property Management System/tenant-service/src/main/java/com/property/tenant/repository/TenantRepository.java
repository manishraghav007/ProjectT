package com.property.tenant.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.property.tenant.entity.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long>{

}
