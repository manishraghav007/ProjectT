package com.property.tenant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.property.tenant.entity.Tenant;
import com.property.tenant.repository.TenantRepository;

@Repository
public class TenantServiceImpl implements TenantServiceIntf{
	
	@Autowired
	private TenantRepository tenantRepository;
	
	public String save(Tenant tenant) {
		 tenantRepository.save(tenant);
		 return "Tenant details added successfully";
	}
	
	public List<Tenant> getAll(){
		return tenantRepository.findAll();
	}

	public void deleteTenant(Long id) {
		// TODO Auto-generated method stub
		 tenantRepository.deleteById(id);
	}
	
	   public boolean existsById(Long id) {
	       return tenantRepository.existsById(id);
	   }
}
