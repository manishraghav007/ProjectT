package com.property.user.controller;

import com.property.user.entity.UserProfile;
import com.property.user.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserProfileController {

    @Autowired
    private UserProfileService userProfileService;

    @PostMapping("/add")
    public String addUser(@RequestBody UserProfile userProfile) {
        return userProfileService.addUserProfile(userProfile);
    }

    @GetMapping("/getall")
    public List<UserProfile> getAllUsers() {
        return userProfileService.getAllUsers();
    }

    @GetMapping("/{id}")
    public UserProfile getUserById(@PathVariable Long id) {
        return userProfileService.getUserProfileById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userProfileService.deleteUserProfile(id);
    }
}