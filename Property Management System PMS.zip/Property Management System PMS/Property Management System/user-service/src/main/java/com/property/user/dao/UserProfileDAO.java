package com.property.user.dao;

import com.property.user.entity.UserProfile;
import java.util.List;

public interface UserProfileDAO {

    String save(UserProfile userProfile);
    List<UserProfile> getAll();
    UserProfile getById(long id);
    void deleteById(Long id);
}
