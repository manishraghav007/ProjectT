package com.property.user.dao;

import com.property.user.entity.UserProfile;
import com.property.user.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class UserProfileDAOImpl implements UserProfileDAO {

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Override
    public String save(UserProfile userProfile) {
        userProfileRepository.save(userProfile);
        return "UserProfile added successfully.";
    }

    @Override
    public List<UserProfile> getAll() {
        return userProfileRepository.findAll();
    }

    @Override
    public UserProfile getById(long id) {
        return userProfileRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteById(Long id) {
        userProfileRepository.deleteById(id);
    }
}
