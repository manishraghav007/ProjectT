package com.property.user.service;

import com.property.user.dao.UserProfileDAO;
import com.property.user.entity.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserProfileService {

    @Autowired
    private UserProfileDAO userProfileDAO;

    public String addUserProfile(UserProfile userProfile) {
        return userProfileDAO.save(userProfile);
    }

    public List<UserProfile> getAllUsers() {
        return userProfileDAO.getAll();
    }

    public UserProfile getUserProfileById(long id) {
        return userProfileDAO.getById(id);
    }

    public void deleteUserProfile(long id) {
        userProfileDAO.deleteById(id);
    }
}
