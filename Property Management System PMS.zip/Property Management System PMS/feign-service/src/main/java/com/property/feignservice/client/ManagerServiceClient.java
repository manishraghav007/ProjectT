package com.property.feignservice.client;

import com.property.feignservice.dto.Manager;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "manager-service", url = "http://localhost:8082/managers")
public interface ManagerServiceClient {

    @PostMapping
    String createManager(@RequestBody Manager manager);

    @GetMapping
    List<Manager> getAllManagers();

    @GetMapping("/{id}")
    Manager getManagerById(@PathVariable("id") Long id);

    @DeleteMapping("/{id}")
    String deleteManager(@PathVariable("id") Long id);
    
   
}
