package com.property.feignservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.property.feignservice.dto.Property;

import jakarta.validation.Valid;
@FeignClient(name="property-service", url="http://localhost:8087/properties")
public interface PropertyServiceClient {

    @PostMapping("/add")
    Property addProperty(@RequestBody @Valid Property property);

    @GetMapping("city/{city}")
    List<Property> getPropertiesByCity(@PathVariable String city);

    @GetMapping("/all")
    List<Property> getAllProperties();

    @PutMapping("/update")
    String updateProperty(@RequestBody @Valid Property property);

    @GetMapping("/rent/{rent}")
    List<Property> getPropertiesByRent(@PathVariable double rent);

    @DeleteMapping("/delete/{id}")
    String deleteProperty(@PathVariable Long id);

    @GetMapping("/manager/{managerId}")
    List<Property> getPropertiesByManager(@PathVariable Long managerId);  // Method for fetching properties assigned to a manager

    @GetMapping("/{id}")
    Property getPropertyById(@PathVariable Long id);  // Fetch property by ID
}
