package com.property.feignservice.controller;

import com.property.feignservice.client.AdminServiceClient;
import com.property.feignservice.client.ManagerServiceClient;
import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.dto.Admin;
import com.property.feignservice.dto.Manager;
import com.property.feignservice.dto.Property;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feign/admin")
public class AdminFeignController {

    @Autowired
    private AdminServiceClient adminServiceClient;

    @Autowired
    private ManagerServiceClient managerServiceClient;

    @Autowired
    private PropertyServiceClient propertyServiceClient;
    // Add an Admin
    @PostMapping("/add")
    public String addAdmin(@RequestBody Admin admin) {
        return adminServiceClient.addAdmin(admin);
    }

    // Get all admins
    @GetMapping("/getall")
    public List<Admin> getAllAdmins() {
        return adminServiceClient.getAllAdmins();
    }

    // Get an Admin by ID
    @GetMapping("/{id}")
    public Admin getAdminById(@PathVariable Long id) {
        return adminServiceClient.getAdminById(id);
    }

    // Delete an Admin
    @DeleteMapping("/{id}")
    public String deleteAdmin(@PathVariable Long id) {
        return adminServiceClient.deleteAdmin(id);
    }

    @GetMapping("/allmanagers")
    public List<Manager> getAllManagers() {
        return managerServiceClient.getAllManagers();
    }
    @PostMapping("/{adminId}/addManager")
    public String addManagerForAdmin(@PathVariable Long adminId, @RequestBody Manager manager) {
        try {
            String managerCreationResponse = managerServiceClient.createManager(manager);
            if (managerCreationResponse != null && !managerCreationResponse.isEmpty()) {
                String adminResponse = adminServiceClient.addManagerForAdmin(adminId, manager);
                System.out.println("Admin Manager Assignment Response: " + adminResponse);
                return adminResponse;
            } else {
                return "Error in creating manager.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error occurred: " + e.getMessage();
        }
    }
    
    //property
    
    @GetMapping("/allproperties")
	public List<Property> getAllProperties(){
		return propertyServiceClient.getAllProperties();
	}
    
    
    @DeleteMapping("/delete/{id}")
	 public String deleteProperty(@PathVariable Long id) {
		 return propertyServiceClient.deleteProperty(id);
	 }
}
