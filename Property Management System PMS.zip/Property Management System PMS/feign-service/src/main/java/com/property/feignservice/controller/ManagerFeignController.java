package com.property.feignservice.controller;

import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.client.ManagerServiceClient;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Manager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feign/manager")
public class ManagerFeignController {

    @Autowired
    private ManagerServiceClient managerServiceClient;

    @Autowired
    private PropertyServiceClient propertyServiceClient;

    @PostMapping
    public String createManager(@RequestBody Manager manager) {
        return managerServiceClient.createManager(manager);
    }

    @GetMapping
    public List<Manager> getAllManagers() {
        return managerServiceClient.getAllManagers();
    }

    @GetMapping("/{id}")
    public Manager getManagerById(@PathVariable Long id) {
        return managerServiceClient.getManagerById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteManager(@PathVariable Long id) {
        return managerServiceClient.deleteManager(id);
    }

    // New endpoint to get all properties assigned to a specific manager
    @GetMapping("/{managerId}/properties")
    public List<Property> getPropertiesAssignedToManager(@PathVariable Long managerId) {
        return propertyServiceClient.getPropertiesByManager(managerId);  // Fetch properties by manager ID
    }

    @PostMapping("/{managerId}/assign-properties")
    public String assignPropertiesToManager(@PathVariable Long managerId, @RequestBody List<Long> propertyIds) {
        for (Long propertyId : propertyIds) {
            Property property = propertyServiceClient.getPropertyById(propertyId);
            property.setManagerId(managerId);  // Assign manager ID to the property
            propertyServiceClient.updateProperty(property);  // Update the property with the manager
        }
        return "Properties assigned to manager successfully";
    }
}
