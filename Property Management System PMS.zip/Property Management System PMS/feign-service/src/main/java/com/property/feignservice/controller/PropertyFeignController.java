package com.property.feignservice.controller;

import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.dto.Property;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
@RestController
@RequestMapping("/feign/property")
public class PropertyFeignController {

    @Autowired
    private PropertyServiceClient propertyFeignClient;

    // Add Property and assign a manager
    @PostMapping("/add")
    public Property addProperty(@RequestBody @Valid Property property) {
        // If the managerId is not already set, throw an error or handle default
        if (property.getManagerId() == null) {
            throw new IllegalArgumentException("Manager ID must be provided to assign a manager.");
        }
        
        // Add the property with the assigned manager
        return propertyFeignClient.addProperty(property);
    }
    
    @GetMapping("city/{city}")
    public List<Property> getPropertiesByCity(@PathVariable String city) {
        return propertyFeignClient.getPropertiesByCity(city);
    }

    @GetMapping("/all")
    public List<Property> getAllProperties() {
        return propertyFeignClient.getAllProperties();
    }

    @PutMapping("/update")
    public String updateProperty(@RequestBody @Valid Property property) {
        return propertyFeignClient.updateProperty(property);
    }

    @GetMapping("/rent/{rent}")
    public List<Property> getPropertiesByRent(@PathVariable double rent) {
        return propertyFeignClient.getPropertiesByRent(rent);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProperty(@PathVariable Long id) {
        return propertyFeignClient.deleteProperty(id);
    }

    // Get properties assigned to a manager
    @GetMapping("/manager/{managerId}")
    public List<Property> getPropertiesByManager(@PathVariable Long managerId) {
        return propertyFeignClient.getPropertiesByManager(managerId);
    }
}
