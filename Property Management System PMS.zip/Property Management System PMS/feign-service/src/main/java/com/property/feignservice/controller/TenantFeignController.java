package com.property.feignservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.property.feignservice.client.TenantServiceClient;
import com.property.feignservice.dto.Tenant;
import com.property.tenant.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/feign/tenant")
public class TenantFeignController {
	
	@Autowired
	private TenantServiceClient tenantService;
	
	@PostMapping("/add")
	public ResponseEntity<String> save(@RequestBody Tenant tenant) {
		 try {
	            // Save tenant if valid
	            String response = tenantService.save(tenant);
	            return ResponseEntity.status(HttpStatus.CREATED).body(response);
	        } catch (Exception e) {
	            // Handle any validation error or other exception
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation failed: " + e.getMessage());
	        }
	}
	
	@GetMapping("/getall")
	public List<Tenant> getAll(){
		return tenantService.getAll();
	}
	
	@GetMapping("/{id}")
	public boolean existsById(Long id) {
		if(tenantService.existsById(id)) {
			return true;
		}else {
			return false;
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {
		 if (!tenantService.existsById(id)) {
	            // If tenant is not found, throw ResourceNotFoundException
	            throw new ResourceNotFoundException("Tenant with ID " + id + " not found.");
	        }
	        tenantService.deleteTenant(id);
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Tenant deleted successfully.");
	    }

}
