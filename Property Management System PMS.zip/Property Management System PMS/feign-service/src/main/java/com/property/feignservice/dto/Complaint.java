package com.property.feignservice.dto;


public class Complaint {

	private Long id; // Unique ID for the complaint
    private String description; // Description of the complaint
    private String status;
    private Long tenantId;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getTenantId() {
		return tenantId;
	}
	public void setTenantId(Long tenantId) {
		this.tenantId = tenantId;
	}
	public Complaint(Long id, String description, String status, Long tenantId) {
		super();
		this.id = id;
		this.description = description;
		this.status = status;
		this.tenantId = tenantId;
	}
	public Complaint() {
		super();
	}

}
