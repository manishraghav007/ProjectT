package com.property.feignservice.dto;

import java.time.LocalDate;

public class Lease {

	private long id;
	private long tenantId;
	private long propertyId;
	private LocalDate startDate;
	private LocalDate endDate;
	private double monthlyRent;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getTenantId() {
		return tenantId;
	}
	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}
	public long getPropertyId() {
		return propertyId;
	}
	public void setPropertyId(long propertyId) {
		this.propertyId = propertyId;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public double getMonthlyRent() {
		return monthlyRent;
	}
	public void setMonthlyRent(double monthlyRent) {
		this.monthlyRent = monthlyRent;
	}
	public Lease(long id, long tenantId, long propertyId, LocalDate startDate, LocalDate endDate, double monthlyRent) {
		super();
		this.id = id;
		this.tenantId = tenantId;
		this.propertyId = propertyId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.monthlyRent = monthlyRent;
	}
	public Lease() {
		super();
	}
	
	
}
