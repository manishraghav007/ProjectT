package com.property.feignservice.dto;

import jakarta.validation.constraints.NotNull;

public class Manager {

    private Long id;

    @NotNull
    private String name;

    private Long adminId;
    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}
    
}
