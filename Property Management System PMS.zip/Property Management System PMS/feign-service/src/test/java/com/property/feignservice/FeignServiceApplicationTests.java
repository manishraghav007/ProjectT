package com.property.feignservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
