package com.property.administration.entity;
import java.util.ArrayList;
import java.util.List;

import com.property.administration.validation.ValidRole;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    
    @NotNull(message = "Name cannot be null")
    @Size(min = 3, max = 100, message = "Name must be between 3 and 100 characters")
    private String name;
    
    @NotNull(message = "Email cannot be null")
    @Email(message = "Email must be valid")
    private String email;
    
    @NotNull
    @ValidRole(message = "Role: ADMIN, MANAGER, USER")
    private String role;
    
   

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

	public Admin(long id, String name, String email, String role) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.role = role;
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
     
	
    // Directly initialize the list to avoid null checks
    @Transient
    private List<Long> managerIds = new ArrayList<>();

    // Getter for managerIds
    public List<Long> getManagerIds() {
        return managerIds;
    }

    // Setter for managerIds
    public void setManagerIds(List<Long> managerIds) {
        this.managerIds = managerIds;
    }
    
    @Transient
    private List<Long> propertyIds=new ArrayList<>();



	public List<Long> getPropertyIds() {
		return propertyIds;
	}

	public void setPropertyIds(List<Long> propertyIds) {
		this.propertyIds = propertyIds;
	}
	@Transient
    private List<Long> LeaseId = new ArrayList<>();



	public List<Long> getLeaseId() {
		return LeaseId;
	}

	public void setLeaseId(List<Long> leaseId) {
		LeaseId = leaseId;
	}
	

}
