package com.property.administration.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.validation.ConstraintViolationException;
import java.util.List;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

	// Handle validation exceptions for Admin and UserProfile entities (e.g.,@Valid)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {

		// Extract validation errors from the exception
		List<FieldError> errors = ex.getBindingResult().getFieldErrors();

		// Concatenate error messages into a single string (Field_Name + Validation Message)
		String errorMessages = errors.stream().map(error -> error.getField() + ": " + error.getDefaultMessage())
				.collect(Collectors.joining(", "));

		// Respond with a BAD_REQUEST status and the error messages
		return new ResponseEntity<>("Validation failed: " + errorMessages, HttpStatus.BAD_REQUEST);
	}

	//Handles constraintviolationException (for Admin
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<String> handleConstraintViolationException(ConstraintViolationException ex) {
		// Collect violation messages for constraints
		String errorMessages = ex.getConstraintViolations().stream()
				.map(violation -> violation.getPropertyPath() + ": " + violation.getMessage())
				.collect(Collectors.joining(", "));

		return new ResponseEntity<>("Constraint violation: " + errorMessages, HttpStatus.BAD_REQUEST);
	}

	// Handle ResourceNotFoundException (for when an Admin entity not found)
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}

	// Handle other general exceptions
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleAllExceptions(Exception ex) {
		return new ResponseEntity<>("An error occurred: " + ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
