package com.property.administration.service;
import com.property.administration.entity.Admin;
import com.property.administration.repository.AdminRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AdminServiceImpl implements AdminServiceIntf{

	@Autowired
	private AdminRepository adminRepository;


	@Override
	public String save(Admin admin) {
		adminRepository.save(admin);
		return "Admin Added Successfully";
	}

	@Override
	public List<Admin> getAll() {
		return adminRepository.findAll();
	}

	@Override
	public Admin getById(long id) {
		return adminRepository.findById(id).orElse(null);
	}

	@Override
	public void deleteById(Long id) {
		adminRepository.deleteById(id);
	}

	@Override
	public boolean existsById(Long id) {
		return adminRepository.existsById(id);
	}

}
