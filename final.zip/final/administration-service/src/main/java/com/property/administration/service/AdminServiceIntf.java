package com.property.administration.service;

import java.util.List;

import com.property.administration.entity.Admin;

public interface AdminServiceIntf {
    String save(Admin admin);
    List<Admin> getAll();
    Admin getById(long id);
    void deleteById(Long id);
    boolean existsById(Long id);
}
