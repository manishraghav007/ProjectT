package com.property.administration.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class RoleValidator implements ConstraintValidator<ValidRole, String> {

    @Override
    public void initialize(ValidRole constraintAnnotation) {
    }

    @Override
    public boolean isValid(String role, ConstraintValidatorContext context) {
        // Assume valid roles are "ADMIN", "MANAGER", "USER"
        return role != null && 
               (role.equalsIgnoreCase("ADMIN") || 
                role.equalsIgnoreCase("MANAGER") || 
                role.equalsIgnoreCase("USER"));
    }

}
