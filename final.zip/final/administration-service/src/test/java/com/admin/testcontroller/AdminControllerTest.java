package com.admin.testcontroller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.property.administration.controller.AdminController;
import com.property.administration.entity.Admin;
import com.property.administration.exception.ResourceNotFoundException;
import com.property.administration.service.AdminServiceImpl;
import com.property.lease.entity.Lease;
import com.property.manager.entity.Manager;
import com.property.p.entity.Property;

class AdminControllerTest {

	@Mock
	private AdminServiceImpl adminService;

	@InjectMocks
	private AdminController adminController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testSaveAdmin() {

		Admin admin = new Admin();
		admin.setName("Test Admin");
		admin.setEmail("test@example.com");
		admin.setRole("ADMIN");

		when(adminService.save(admin)).thenReturn("Admin Added Successfully");

		String result = adminController.save(admin);

		assertEquals("Admin Added Successfully", result);
		verify(adminService, times(1)).save(admin);
	}

	@Test
	void testGetAllAdmins() {

		List<Admin> admins = Arrays.asList(new Admin(1L, "Admin1", "admin1@example.com", "ADMIN"),
				new Admin(2L, "Admin2", "admin2@example.com", "MANAGER"));

		when(adminService.getAll()).thenReturn(admins);

		List<Admin> result = adminController.getAllAdmins();

		assertEquals(2, result.size());
		verify(adminService, times(1)).getAll();
	}

	@Test
	void testGetAllAdminsEmptyList() {

		when(adminService.getAll()).thenReturn(null);

		List<Admin> result = adminController.getAllAdmins();

		assertTrue(result.isEmpty());
	}

	@Test
	void testGetAdminByIdSuccess() {

		Long adminId = 1L;
		Admin admin = new Admin(adminId, "Test Admin", "test@example.com", "ADMIN");

		when(adminService.getById(adminId)).thenReturn(admin);

		Admin result = adminController.getAdminById(adminId);

		assertNotNull(result);
		assertEquals(adminId, result.getId());
		verify(adminService, times(1)).getById(adminId);
	}

	@Test
	void testGetAdminByIdNotFound() {

		Long adminId = 999L;
		when(adminService.getById(adminId)).thenReturn(null);

		assertThrows(ResourceNotFoundException.class, () -> {
			adminController.getAdminById(adminId);
		});
	}

	@Test
	void testDeleteAdminSuccess() {

		Long adminId = 1L;
		when(adminService.existsById(adminId)).thenReturn(true);
		doNothing().when(adminService).deleteById(adminId);

		String result = adminController.deleteAdmin(adminId);

		assertEquals("Record of " + adminId + " is deleted", result);
		verify(adminService, times(1)).deleteById(adminId);
	}

	@Test
	void testDeleteAdminNotFound() {

		Long adminId = 999L;
		when(adminService.existsById(adminId)).thenReturn(false);

		assertThrows(ResourceNotFoundException.class, () -> {
			adminController.deleteAdmin(adminId);
		});
	}

	@Test
	void testAddManagerToAdmin() {

		Long adminId = 1L;
		Admin admin = new Admin();
		admin.setId(adminId);
		admin.setManagerIds(new ArrayList<>());

		Manager manager = new Manager();
		manager.setId(101L);

		when(adminService.getById(adminId)).thenReturn(admin);
		when(adminService.save(admin)).thenReturn("Admin Updated");

		String result = adminController.addManagerToAdmin(adminId, manager);

		assertEquals("Manager successfully added to admin!", result);
		assertTrue(admin.getManagerIds().contains(manager.getId()));
		verify(adminService, times(1)).save(admin);
	}

	@Test
	void testAddPropertyToAdmin() {

		Long adminId = 1L;
		Admin admin = new Admin();
		admin.setId(adminId);
		admin.setPropertyIds(new ArrayList<>());

		Property property = new Property();
		property.setId(201L);

		when(adminService.getById(adminId)).thenReturn(admin);
		when(adminService.save(admin)).thenReturn("Admin Updated");

		String result = adminController.addPropertyToAdmin(adminId, property);

		assertEquals("Property successfully added to admin!", result);
		assertTrue(admin.getPropertyIds().contains(property.getId()));
		verify(adminService, times(1)).save(admin);
	}

	@Test
	void testAddLeaseToAdmin() {

		Long adminId = 1L;
		Admin admin = new Admin();
		admin.setId(adminId);
		admin.setLeaseId(new ArrayList<>());

		Lease lease = new Lease();
		lease.setId(301L);

		when(adminService.getById(adminId)).thenReturn(admin);
		when(adminService.save(admin)).thenReturn("Admin Updated");

		String result = adminController.addLeaseToAdmin(adminId, lease);

		assertEquals("Lease successfully added to admin!", result);
		assertTrue(admin.getLeaseId().contains(lease.getId()));
		verify(adminService, times(1)).save(admin);
	}
}