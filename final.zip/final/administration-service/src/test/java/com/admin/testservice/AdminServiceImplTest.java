package com.admin.testservice;
import com.property.administration.entity.Admin;
import com.property.administration.repository.AdminRepository;
import com.property.administration.service.AdminServiceImpl;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
class AdminServiceImplTest {
 
    @InjectMocks
    private AdminServiceImpl adminService; 
 
    @Mock
    private AdminRepository adminRepository; 
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); 
    }
 
    @Test
    void testSave() {
        Admin admin = new Admin(1L, "Manish Raghav", "manish.raghav@example.com", "ADMIN");
        when(adminRepository.save(admin)).thenReturn(admin);
        String result = adminService.save(admin);
        assertEquals("Admin Added Successfully", result);
        verify(adminRepository, times(1)).save(admin);
    }
 
    @Test
    void testGetAll() {
        List<Admin> admins = Arrays.asList(
                new Admin(1L, "Himanshu Vyas", "himanshu.vyas@example.com", "ADMIN"),
                new Admin(2L, "Priya Sharma", "priya.sharma@example.com", "MANAGER")
        );
        when(adminRepository.findAll()).thenReturn(admins);
        List<Admin> result = adminService.getAll();
        assertNotNull(result);
        assertEquals(2, result.size());
        verify(adminRepository, times(1)).findAll();
    }
 
    @Test
    void testGetById() {
        Admin admin = new Admin(1L, "Ravi Kumar", "ravi.kumar@example.com", "ADMIN");
        when(adminRepository.findById(1L)).thenReturn(Optional.of(admin));
        Admin result = adminService.getById(1L);
        assertNotNull(result);
        assertEquals("Ravi Kumar", result.getName());
        verify(adminRepository, times(1)).findById(1L); 
    }
 
    @Test
    void testGetByIdNotFound() {
        when(adminRepository.findById(1L)).thenReturn(Optional.empty());
        Admin result = adminService.getById(1L);

        assertNull(result);
        verify(adminRepository, times(1)).findById(1L);
    }
 
    @Test
    void testDeleteById() {
        // Act
        adminService.deleteById(1L);
 
        // Assert
        verify(adminRepository, times(1)).deleteById(1L); 
    }
 
    @Test
    void testExistsById() {
        when(adminRepository.existsById(1L)).thenReturn(true);
        boolean exists = adminService.existsById(1L);
        assertTrue(exists);
        verify(adminRepository, times(1)).existsById(1L); 
    }
 
    @Test
    void testExistsByIdFalse() {
        when(adminRepository.existsById(2L)).thenReturn(false);
        boolean exists = adminService.existsById(2L);

        assertFalse(exists);
        verify(adminRepository, times(1)).existsById(2L);
    }
}