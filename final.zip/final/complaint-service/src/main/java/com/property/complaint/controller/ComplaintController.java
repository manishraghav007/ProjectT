// ComplaintController.java
package com.property.complaint.controller;

import com.property.complaint.entity.Complaint;
import com.property.complaint.exception.ResourceNotFoundException;
import com.property.complaint.service.ComplaintServiceImpl;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/complaints")
@Validated
public class ComplaintController {

    @Autowired
    private ComplaintServiceImpl complaintService;

    @PostMapping("/add")
    public Complaint createComplaint(@RequestBody @Valid Complaint complaint) {
    	 try {
             return complaintService.saveComplaint(complaint);
         } catch (Exception e) {
             throw new RuntimeException("Failed to create complaint: " + e.getMessage());
         }
    }

    @GetMapping("/all")
    public List<Complaint> getAllComplaints() {
        return complaintService.getAllComplaints();
    }
    
    @GetMapping("/tenant/{tenantId}")
    public List<Complaint> getComplaintsByTenantId(@PathVariable Long tenantId) {
    		return complaintService.findByTenantId(tenantId);
    	}

    
    @GetMapping("/{id}")
    public List<Complaint> getComplaintById(@PathVariable Long id) {
    	 List<Complaint> complaints = complaintService.getComplaintsByTenantId(id);
         if (complaints.isEmpty()) {
             throw new ResourceNotFoundException("No complaints found for tenant with ID " + id);
         }
         return complaints;
    }

    @DeleteMapping("/{id}")
    public String deleteComplaint(@PathVariable Long id) {
    	Complaint complaint = complaintService.getComplaintById(id);
        if (complaint == null) {
            throw new ResourceNotFoundException("Complaint with ID " + id + " not found.");
        }
        return "Deleted "+id+" successfully";
    }
}
