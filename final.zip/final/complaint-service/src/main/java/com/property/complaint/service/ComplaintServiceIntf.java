package com.property.complaint.service;

import java.util.List;

import com.property.complaint.entity.Complaint;

public interface ComplaintServiceIntf {
    Complaint saveComplaint(Complaint complaint);

    List<Complaint> getAllComplaints();
    
    List<Complaint> getComplaintsByTenantId(Long tenantId);
    
    Complaint getComplaintById(Long id);

    void deleteComplaint(Long id);

    boolean existsById(Long id);
    
    List<Complaint> findByTenantId(Long tenantId);
}
