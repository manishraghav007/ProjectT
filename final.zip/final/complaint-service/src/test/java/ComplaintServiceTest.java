
 
import com.property.complaint.entity.Complaint;
import com.property.complaint.repository.ComplaintRepository;
import com.property.complaint.service.ComplaintServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
class ComplaintServiceTest {
 
    @InjectMocks
    private ComplaintServiceImpl complaintService;
 
    @Mock
    private ComplaintRepository complaintRepository;
 
    private Complaint complaint1, complaint2;
 
    @BeforeEach
    void setUp() {
        
        MockitoAnnotations.openMocks(this); 
        complaint1 = new Complaint(1L, "Fan not working", "Pending", 5L);
        complaint2 = new Complaint(2L, "Light not working", "Resolved", 8L);
    }
 
    @Test
    void testSaveComplaint() {
        when(complaintRepository.save(complaint1)).thenReturn(complaint1);
        Complaint result = complaintService.saveComplaint(complaint1);
        assertNotNull(result);
        assertEquals("Fan not working", result.getDescription());
        verify(complaintRepository).save(complaint1); 
    }
 
    @Test
    void testGetAllComplaints() {
        when(complaintRepository.findAll()).thenReturn(Arrays.asList(complaint1, complaint2));
        List<Complaint> result = complaintService.getAllComplaints();
        // Assertions
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals("Fan not working", result.get(0).getDescription());
    }
 
    @Test
    void testGetComplaintsByTenantId() {
        when(complaintRepository.findByTenantId(5L)).thenReturn(Arrays.asList(complaint1));
        List<Complaint> result = complaintService.getComplaintsByTenantId(5L);
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(5L, result.get(0).getTenantId());
    }
 
    @Test
    void testGetComplaintById() {
        when(complaintRepository.findById(1L)).thenReturn(Optional.of(complaint1));
        Complaint result = complaintService.getComplaintById(1L);
        assertNotNull(result);
        assertEquals("Fan not working", result.getDescription());
    }
 
    @Test
    void testGetComplaintByIdNotFound() {
        when(complaintRepository.findById(99L)).thenReturn(Optional.empty());
        Complaint result = complaintService.getComplaintById(99L);
        assertNull(result); 
    }
 
    @Test
    void testDeleteComplaint() {
        complaintService.deleteComplaint(1L);
        verify(complaintRepository).deleteById(1L);
    }
 
    @Test
    void testExistsById() {
        when(complaintRepository.existsById(1L)).thenReturn(true);
        boolean result = complaintService.existsById(1L);
        assertTrue(result); 
    }
 
    @Test
    void testExistsByIdFalse() {
        when(complaintRepository.existsById(99L)).thenReturn(false);
        boolean result = complaintService.existsById(99L);
        assertFalse(result); 
    }
}