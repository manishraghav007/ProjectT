package com.property.complaint.controller;

import com.property.complaint.entity.Complaint;
import com.property.complaint.exception.ResourceNotFoundException;
import com.property.complaint.service.ComplaintServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ComplaintControllerTest {

    @Mock
    private ComplaintServiceImpl complaintService;

    @InjectMocks
    private ComplaintController complaintController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateComplaint_Success() {
        // Arrange
        Complaint complaint = new Complaint(null, "Broken pipe", "Pending", 1L);
        Complaint savedComplaint = new Complaint(1L, "Broken pipe", "Pending", 1L);
        
        when(complaintService.saveComplaint(complaint)).thenReturn(savedComplaint);

        // Act
        Complaint result = complaintController.createComplaint(complaint);

        // Assert
        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(complaintService, times(1)).saveComplaint(complaint);
    }

    @Test
    void testCreateComplaint_Exception() {
        // Arrange
        Complaint complaint = new Complaint(null, "Broken pipe", "Pending", 1L);
        
        when(complaintService.saveComplaint(complaint)).thenThrow(new RuntimeException("Database error"));

        // Act & Assert
        assertThrows(RuntimeException.class, () -> {
            complaintController.createComplaint(complaint);
        });
    }

    @Test
    void testGetAllComplaints_Success() {
        // Arrange
        List<Complaint> complaints = Arrays.asList(
            new Complaint(1L, "Broken pipe", "Pending", 1L),
            new Complaint(2L, "Electrical issue", "In Progress", 2L)
        );
        
        when(complaintService.getAllComplaints()).thenReturn(complaints);

        // Act
        List<Complaint> result = complaintController.getAllComplaints();

        // Assert
        assertEquals(2, result.size());
        verify(complaintService, times(1)).getAllComplaints();
    }

    @Test
    void testGetComplaintsByTenantId_Success() {
        // Arrange
        Long tenantId = 1L;
        List<Complaint> complaints = Arrays.asList(
            new Complaint(1L, "Broken pipe", "Pending", tenantId),
            new Complaint(2L, "Electrical issue", "In Progress", tenantId)
        );
        
        when(complaintService.findByTenantId(tenantId)).thenReturn(complaints);

        // Act
        List<Complaint> result = complaintController.getComplaintsByTenantId(tenantId);

        // Assert
        assertEquals(2, result.size());
        assertEquals(tenantId, result.get(0).getTenantId());
        verify(complaintService, times(1)).findByTenantId(tenantId);
    }

    @Test
    void testGetComplaintById_Success() {
        // Arrange
        Long tenantId = 1L;
        List<Complaint> complaints = Arrays.asList(
            new Complaint(1L, "Broken pipe", "Pending", tenantId),
            new Complaint(2L, "Electrical issue", "In Progress", tenantId)
        );
        
        when(complaintService.getComplaintsByTenantId(tenantId)).thenReturn(complaints);

        // Act
        List<Complaint> result = complaintController.getComplaintById(tenantId);

        // Assert
        assertFalse(result.isEmpty());
        assertEquals(2, result.size());
        verify(complaintService, times(1)).getComplaintsByTenantId(tenantId);
    }

    @Test
    void testGetComplaintById_NoComplaints() {
        // Arrange
        Long tenantId = 999L;
        
        when(complaintService.getComplaintsByTenantId(tenantId)).thenReturn(Arrays.asList());

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            complaintController.getComplaintById(tenantId);
        });
    }

    @Test
    void testDeleteComplaint_Success() {
        // Arrange
        Long complaintId = 1L;
        Complaint complaint = new Complaint(complaintId, "Broken pipe", "Pending", 1L);
        
        when(complaintService.getComplaintById(complaintId)).thenReturn(complaint);

        // Act
        String result = complaintController.deleteComplaint(complaintId);

        // Assert
        assertEquals("Deleted 1 successfully", result);
        verify(complaintService, times(1)).getComplaintById(complaintId);
    }

    @Test
    void testDeleteComplaint_NotFound() {
        // Arrange
        Long complaintId = 999L;
        
        when(complaintService.getComplaintById(complaintId)).thenReturn(null);

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            complaintController.deleteComplaint(complaintId);
        });
    }
}