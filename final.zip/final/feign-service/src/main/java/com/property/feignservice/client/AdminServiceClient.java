package com.property.feignservice.client;

import com.property.administration.exception.ResourceNotFoundException;
import com.property.feignservice.dto.Admin;
import com.property.feignservice.dto.Lease;
import com.property.feignservice.dto.Manager;
import com.property.feignservice.dto.Property;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "administration-service", url = "http://localhost:9001/admin")
public interface AdminServiceClient {

    @PostMapping("/add")
    String addAdmin(@RequestBody Admin admin);

    @GetMapping("/getall")
    List<Admin> getAllAdmins();

    @GetMapping("/{id}")
    Admin getAdminById(@PathVariable("id") Long id);

    @DeleteMapping("/{id}")
    String deleteAdmin(@PathVariable("id") Long id);

    @GetMapping
    List<Manager> getAllManagers();
    
    @PostMapping("/{adminId}/addManager")
    String addManagerForAdmin(@PathVariable("adminId") Long adminId, @RequestBody Manager manager);
    
    //property
    @GetMapping("/allproperties")
	List<Property> getAllProperties();
    
    @DeleteMapping("/delete/{id}")
	 String deleteProperty(@PathVariable Long id);
   
    @PostMapping("/{adminId}/addProperty")
    public String addPropertyToAdmin( @PathVariable Long adminId, @RequestBody Property property) ;

    @PostMapping("/{adminId}/addLease")
    public String addLeaseToAdmin( @PathVariable Long adminId, @RequestBody Lease lease);
}

