package com.property.feignservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.property.feignservice.dto.Complaint;

import jakarta.validation.Valid;

@FeignClient(name = "complaint-service", url = "http://localhost:9001/complaints")
public interface ComplaintServiceClient {

	    @PostMapping("/add")
	    public Complaint createComplaint(@RequestBody @Valid Complaint complaint) ;
	    
	    @GetMapping("/all")
	    public List<Complaint> getAllComplaints();
	    
	    @GetMapping("/tenant/{tenantId}")
	    public List<Complaint> getComplaintsByTenantId(@PathVariable Long tenantId) ;

	    
	    @GetMapping("/{id}")
	    public List<Complaint> getComplaintById(@PathVariable Long id) ;
	    
	    @DeleteMapping("/{id}")
	    public String deleteComplaint(@PathVariable Long id);
}
