package com.property.feignservice.client;

import com.property.feignservice.dto.Admin;
import com.property.feignservice.dto.Manager;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Tenant;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "manager-service", url = "http://localhost:9001/managers")
public interface ManagerServiceClient {

    @PostMapping
    String createManager(@RequestBody Manager manager);

    @GetMapping
    List<Manager> getAllManagers();

    @GetMapping("/{id}")
    Manager getManagerById(@PathVariable("id") Long id);

    @DeleteMapping("/{id}")
    String deleteManager(@PathVariable("id") Long id);
    
    @GetMapping("/getProperties/{managerId}")
    Manager getByManagerId(@PathVariable("managerId") long managerId);
   
    @GetMapping("/findallbyadminid/{adminId}")
    public List<Manager> findAllByAdminId(@PathVariable("adminId") long adminId);
    
    @PostMapping("/{managerId}/addtenant")
    public String addTenanttoManager( @PathVariable Long managerId, @RequestBody Tenant tenant);
}
