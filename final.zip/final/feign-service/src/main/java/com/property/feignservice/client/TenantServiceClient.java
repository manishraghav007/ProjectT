package com.property.feignservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.property.feignservice.dto.Complaint;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Tenant;

@FeignClient(name = "tenant-service", url = "http://localhost:9001/tenant")
public interface TenantServiceClient {

	@PostMapping("/add")
	public String save(@RequestBody Tenant tenant);
	
	@GetMapping("/getall")
	public List<Tenant> getAll();
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable("id") Long id);

	@GetMapping("{/id}")
	public boolean existsById(Long id);
	
	 @GetMapping("/getById/{id}")
	 public Tenant getTenantById(@PathVariable("id") Long id);

	 @GetMapping("/getallbyproperty/{propertyId}")
	    public List<Tenant> getAllByPropertyId(@PathVariable Long propertyId);
	 
	 @PostMapping("/{tenantId}/addComplaint")
		public String addComplaintTotenant(@PathVariable Long tenantId, @RequestBody Complaint complaint);
}
