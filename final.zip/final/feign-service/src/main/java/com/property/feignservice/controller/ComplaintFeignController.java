package com.property.feignservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.property.complaint.exception.ResourceNotFoundException;
import com.property.feignservice.client.ComplaintServiceClient;
import com.property.feignservice.dto.Complaint;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/feign/complaint")
public class ComplaintFeignController {

	@Autowired
	private ComplaintServiceClient complaintService;
	
	@PostMapping("/add")
    public Complaint createComplaint(@RequestBody @Valid Complaint complaint) {
    	 try {
             return complaintService.createComplaint(complaint);
         } catch (Exception e) {
             throw new RuntimeException("Failed to create complaint: " + e.getMessage());
         }
    }

    @GetMapping("/all")
    public List<Complaint> getAllComplaints() {
        return complaintService.getAllComplaints();
    }
    
    @GetMapping("/tenant/{tenantId}")
    public List<Complaint> getComplaintsByTenantId(@PathVariable Long tenantId) {

    	return complaintService.getComplaintsByTenantId(tenantId);
    }

    
    @GetMapping("/{id}")
    public List<Complaint> getComplaintById(@PathVariable Long id) {
    	 return complaintService.getComplaintsByTenantId(id);
    }

    @DeleteMapping("/{id}")
    public String deleteComplaint(@PathVariable Long id) {
    	Complaint complaint = (Complaint) complaintService.getComplaintById(id);
        if (complaint == null) {
            throw new ResourceNotFoundException("Complaint with ID " + id + " not found.");
        }
        return "Deleted "+id+" successfully";
    }	
}
