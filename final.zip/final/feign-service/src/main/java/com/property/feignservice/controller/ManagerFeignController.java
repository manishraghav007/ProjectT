package com.property.feignservice.controller;

import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.client.TenantServiceClient;
import com.property.administration.exception.ResourceNotFoundException;
import com.property.feignservice.client.ManagerServiceClient;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Tenant;
import com.property.feignservice.dto.Manager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/feign/manager")
public class ManagerFeignController {

    @Autowired
    private ManagerServiceClient managerServiceClient;

    @Autowired
    private PropertyServiceClient propertyServiceClient;
    
    @Autowired
    private TenantServiceClient tenantServiceClient;

    @PostMapping
    public String createManager(@RequestBody Manager manager) {
        return managerServiceClient.createManager(manager);
    }

    @GetMapping
    public List<Manager> getAllManagers() {
        return managerServiceClient.getAllManagers();
    }

    @GetMapping("/{id}")
    public Manager getManagerById(@PathVariable Long id) {
        return managerServiceClient.getManagerById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteManager(@PathVariable Long id) {
        return managerServiceClient.deleteManager(id);
    }

    
    @GetMapping("/getProperties/{managerId}")
    public Manager getByManagerId(@PathVariable("managerId") long managerId) {
    	Manager manager = managerServiceClient.getManagerById(managerId);//manager microservice
    	System.out.println(manager);
    	List<Property> clist=propertyServiceClient.getAllByManagerId(managerId);//property microservice
    	
    	manager.setProperties(clist);
    	return manager;
    }
    
    @GetMapping("/findallbyadminid/{adminId}")
    public List<Manager> findAllByAdminId(@PathVariable("adminId") long adminId){
 	   return managerServiceClient.findAllByAdminId(adminId);
    }
    
    @PostMapping("/{managerId}/addtenant")
    public String addTenanttoManager( @PathVariable Long managerId, @RequestBody Tenant tenant) {
    	try {
            String tenantresponse = tenantServiceClient.save(tenant);
            if (tenantresponse != null ) {
                String managerResponse = managerServiceClient.addTenanttoManager(managerId,tenant);
                System.out.println(" Manager Tenant Assignment Response: " + managerResponse);
                return managerResponse;
            } else {
                return "Error in creating tenant.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error occurred: " + e.getMessage();
        }
    }
    
    @GetMapping("/{managerId}/tenant")
    public List<Tenant> getAllTenantForManager(@PathVariable Long managerId) {
    	if(managerServiceClient.getManagerById(managerId)==null) {
    		throw new ResourceNotFoundException("Manager with ID " + managerId + " not found");
    	}else {
    		 List<Property> properties = propertyServiceClient.getAllByManagerId(managerId);
    	        List<Tenant> tenant=new ArrayList<>();
    	        for (Property property:properties) {
    	        	List<Tenant> propertyTenants = tenantServiceClient.getAllByPropertyId(property.getId());
    	        	tenant.addAll(propertyTenants);
    	        }
    	        return tenant;
    	}
    }
    	
    	@GetMapping("/{managerId}/property")
        public List<Property> getAllPropertyForManager(@PathVariable Long managerId) {
        	if(managerServiceClient.getByManagerId(managerId)==null) {
        		throw new ResourceNotFoundException("Manager with ID " + managerId + " not found");
        	}else {
        		return propertyServiceClient.getAllByManagerId(managerId);
        	}
    	
    	
    }
    	
    }

