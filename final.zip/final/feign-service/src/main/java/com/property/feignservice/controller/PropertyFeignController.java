package com.property.feignservice.controller;

import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.client.TenantServiceClient;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Tenant;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
@RestController
@RequestMapping("/feign/property")
public class PropertyFeignController {

    @Autowired
    private PropertyServiceClient propertyFeignClient;
    
    @Autowired
    private TenantServiceClient tenantServiceClient;
    

    @PostMapping("/add")
    public Property addProperty(@RequestBody @Valid Property property) {
        if (property.getManagerId() == null) {
            throw new IllegalArgumentException("Manager ID must be provided to assign a manager.");
        }
        return propertyFeignClient.addProperty(property);
    }
    
    @GetMapping("/{id}")
    public Property getPropertyById(@PathVariable Long id) {
        return propertyFeignClient.getPropertyById(id);
    }
    
    @GetMapping("city/{city}")
    public List<Property> getPropertiesByCity(@PathVariable String city) {
        return propertyFeignClient.getPropertiesByCity(city);
    }

    @GetMapping("/all")
    public List<Property> getAllProperties() {
        return propertyFeignClient.getAllProperties();
    }

    @PutMapping("/update")
    public String updateProperty(@RequestBody @Valid Property property) {
        return propertyFeignClient.updateProperty(property);
    }

    @GetMapping("/rent/{rent}")
    public List<Property> getPropertiesByRent(@PathVariable double rent) {
        return propertyFeignClient.getPropertiesByRent(rent);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProperty(@PathVariable Long id) {
        return propertyFeignClient.deleteProperty(id);
    }

    @GetMapping("/getproperties/{managerId}")
    public List<Property> getByManagerId(@PathVariable Long managerId) {
        return propertyFeignClient.getAllByManagerId(managerId);
    }
    @GetMapping("/getbytenant/{propertyId}")
    public Property getPropertiesByTenantId(@PathVariable Long propertyId) {
    		Property property=propertyFeignClient.getPropertyById(propertyId);
    		List<Tenant> tenant=tenantServiceClient.getAllByPropertyId(propertyId);
    		property.setTenant(tenant);
    		return property;
    	}
}
