package com.property.feignservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.property.feignservice.client.ComplaintServiceClient;
import com.property.feignservice.client.LeaseServiceClient;
import com.property.feignservice.client.PropertyServiceClient;
import com.property.feignservice.client.TenantServiceClient;
import com.property.feignservice.dto.Admin;
import com.property.feignservice.dto.Complaint;
import com.property.feignservice.dto.Lease;
import com.property.feignservice.dto.Manager;
import com.property.feignservice.dto.Property;
import com.property.feignservice.dto.Tenant;
import com.property.tenant.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/feign/tenant")
public class TenantFeignController {
	
	@Autowired
	private TenantServiceClient tenantServiceClient;
	
	@Autowired
	private LeaseServiceClient leaseServiceClient;
	
	@Autowired
	private ComplaintServiceClient complaintServiceClient;

	
	
	@PostMapping("/add")
	public ResponseEntity<String> save(@RequestBody Tenant tenant) {
		 try {
	            // Save tenant if valid
	            String response = tenantServiceClient.save(tenant);
	            return ResponseEntity.status(HttpStatus.CREATED).body(response);
	        } catch (Exception e) {
	            // Handle any validation error or other exception
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation failed: " + e.getMessage());
	        }
	}
	
	@GetMapping("/getall")
	public List<Tenant> getAll(){
		return tenantServiceClient.getAll();
	}
	
	@GetMapping("/{id}")
	public boolean existsById(Long id) {
		if(tenantServiceClient.existsById(id)) {
			return true;
		}else {
			return false;
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {
		 if (!tenantServiceClient.existsById(id)) {
	            // If tenant is not found, throw ResourceNotFoundException
	            throw new ResourceNotFoundException("Tenant with ID " + id + " not found.");
	        }
	        tenantServiceClient.deleteTenant(id);
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Tenant deleted successfully.");
	}
	
	 @GetMapping("/getById/{id}")
	 public Tenant getTenantById(@PathVariable("id") Long id) {
		return tenantServiceClient.getTenantById(id);
	}
	
	 @GetMapping("/getleasebytenant/{tenantId}")
	    public Tenant getLeasesByTenantId(@PathVariable("tenantId") Long tenantId) {
	    	Tenant tenant = tenantServiceClient.getTenantById(tenantId);
	    	System.out.println(tenant);
	    	List<Lease> clist=leaseServiceClient.findByTenantId(tenantId);
	    	
	    	tenant.setLeases(clist);
	    	return tenant;
	    }
	 @GetMapping("/tenant/{tenantId}")
	    public Tenant getComplaintsByTenantId(@PathVariable Long tenantId) {
	    		Tenant tenant=tenantServiceClient.getTenantById(tenantId);
	    		List<Complaint> Complaint=complaintServiceClient.getComplaintsByTenantId(tenantId);
	    		tenant.setComplaints(Complaint);
	    		return tenant;
	    	}

	 
	 @GetMapping("/getallbyproperty/{propertyId}")
	    public List<Tenant> getAllByPropertyId(@PathVariable Long propertyId){
		 return tenantServiceClient.getAllByPropertyId(propertyId);
	 }
	 
	 @PostMapping("/{tenantId}/addComplaint")
		public String addComplaintTotenant(@PathVariable Long tenantId, @RequestBody Complaint complaint) {
		 try {
	            Complaint complaintresponse = complaintServiceClient.createComplaint(complaint);
	            if (complaintresponse != null ) {
	                String tenantResponse = tenantServiceClient.addComplaintTotenant(tenantId,complaint);
	                System.out.println(" Complaint Tenant Assignment Response: " + tenantResponse);
	                return tenantResponse;
	            } else {
	                return "Error in creating complaint.";
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	            return "Error occurred: " + e.getMessage();
		 }
	 }
	 
}
