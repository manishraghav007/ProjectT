package com.property.feignservice.dto;

import java.util.List;


public class Manager {

    private Long id;


    private String name;

    private Long adminId;
    
    
    private List<Property> properties;
    
    
    public Manager(Long id, String name, Long adminId, List<Property> properties) {
		super();
		this.id = id;
		this.name = name;
		this.adminId = adminId;
		this.properties = properties;
	}

	public Manager() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}
	 public List<Property> getProperties() {
	        return properties;
	    }

	    public void setProperties(List<Property> properties) {
	        this.properties = properties;
	    }
}
