package com.property.feignservice.dto;

import java.util.List;

public class Property {

    private Long id;
    private String name;
    private String city;
    private String address;
    private double rent;
    
    private Long managerId; 
    private Long adminId;
    private List<Tenant> tenant;
    
    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getRent() {
        return rent;
    }

    public void setRent(double rent) {
        this.rent = rent;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

	public List<Tenant> getTenant() {
		return tenant;
	}

	public void setTenant(List<Tenant> tenant) {
		this.tenant = tenant;
	}

	public Property(Long id, String name, String city, String address, double rent, Long managerId,
			List<Tenant> tenant) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.address = address;
		this.rent = rent;
		this.managerId = managerId;
		this.tenant = tenant;
	}

	
    
}
