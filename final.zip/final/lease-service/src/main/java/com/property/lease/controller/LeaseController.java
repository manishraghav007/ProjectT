package com.property.lease.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.property.lease.Service.LeaseServiceImpl;
import com.property.lease.entity.Lease;
import com.property.lease.exception.ResourceNotFoundException;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/leases")
@Validated
public class LeaseController {

	@Autowired
	private LeaseServiceImpl leaseService;
	
	@PostMapping("/add")
	public String addLease(@RequestBody @Valid Lease lease) {
		
            return leaseService.save(lease);
        
		}
	
	@GetMapping("/getbyid/{id}")
	public Lease getLeaseById(@PathVariable Long id) {
		 return leaseService.findById(id);
	}
	
	@GetMapping("/getall")
	public List<Lease> getAllLeases(){
		return leaseService.findAll();
	}
	
	@DeleteMapping("/{id}")
	public String deleteLease(@PathVariable Long id) {
		 Lease lease = leaseService.findById(id);
	        if (lease == null) {
	            throw new ResourceNotFoundException("Lease with ID " + id + " not found.");
	        }
	        leaseService.deleteById(id);
	        return "Lease with ID " + id + " successfully deleted.";
	    }
	
	@GetMapping("/gettenantsbylease/{tenantId}")
	public List<Lease> getTenantsByLeaae(@PathVariable long tenantId){
		return leaseService.findByTenantId(tenantId);
	}

}
