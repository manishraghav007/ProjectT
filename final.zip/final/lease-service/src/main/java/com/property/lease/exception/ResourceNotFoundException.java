package com.property.lease.exception;

public class ResourceNotFoundException extends RuntimeException{
	 public ResourceNotFoundException(String message) {
	        super(message);
	    }
}
