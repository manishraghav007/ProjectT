package com.property.lease.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.property.lease.entity.Lease;

@Repository
public interface LeaseRepository extends JpaRepository<Lease, Long>{

	public List<Lease> findByTenantId(long tenantId);}
