package com.lease.testcontroller;


import com.property.lease.Service.LeaseServiceImpl;
import com.property.lease.controller.LeaseController;
import com.property.lease.entity.Lease;
import com.property.lease.exception.ResourceNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LeaseControllerTest {

    @Mock
    private LeaseServiceImpl leaseService;

    @InjectMocks
    private LeaseController leaseController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // Helper method to create a sample Lease
    private Lease createSampleLease(Long id, Long tenantId, Long propertyId) {
        Lease lease = new Lease();
        lease.setId(id);
        lease.setTenantId(tenantId);
        lease.setPropertyId(propertyId);
        lease.setStartDate(LocalDate.now().minusMonths(1));
        lease.setEndDate(LocalDate.now().plusMonths(11));
        lease.setMonthlyRent(1000.0);
        return lease;
    }

    @Test
    void testAddLease_Success() {
        // Arrange
        Lease lease = createSampleLease(null, 1L, 100L);
        
        when(leaseService.save(lease)).thenReturn("Lease details added");

        // Act
        String result = leaseController.addLease(lease);

        // Assert
        assertEquals("Lease details added", result);
        verify(leaseService, times(1)).save(lease);
    }

    @Test
    void testGetLeaseById_Success() {
        // Arrange
        Long leaseId = 1L;
        Lease lease = createSampleLease(leaseId, 1L, 100L);
        
        when(leaseService.findById(leaseId)).thenReturn(lease);

        // Act
        Lease result = leaseController.getLeaseById(leaseId);

        // Assert
        assertNotNull(result);
        assertEquals(leaseId, result.getId());
        verify(leaseService, times(1)).findById(leaseId);
    }

    @Test
    void testGetLeaseById_NotFound() {
        // Arrange
        Long leaseId = 999L;
        
        when(leaseService.findById(leaseId))
            .thenThrow(new ResourceNotFoundException("Lease with ID " + leaseId + " not found."));

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            leaseController.getLeaseById(leaseId);
        });
    }

    @Test
    void testGetAllLeases_Success() {
        // Arrange
        List<Lease> leases = Arrays.asList(
            createSampleLease(1L, 1L, 100L),
            createSampleLease(2L, 2L, 200L)
        );
        
        when(leaseService.findAll()).thenReturn(leases);

        // Act
        List<Lease> result = leaseController.getAllLeases();

        // Assert
        assertEquals(2, result.size());
        verify(leaseService, times(1)).findAll();
    }

    @Test
    void testDeleteLease_Success() {
        // Arrange
        Long leaseId = 1L;
        Lease lease = createSampleLease(leaseId, 1L, 100L);
        
        when(leaseService.findById(leaseId)).thenReturn(lease);
        doNothing().when(leaseService).deleteById(leaseId);

        // Act
        String result = leaseController.deleteLease(leaseId);

        // Assert
        assertEquals("Lease with ID " + leaseId + " successfully deleted.", result);
        verify(leaseService, times(1)).findById(leaseId);
        verify(leaseService, times(1)).deleteById(leaseId);
    }

    @Test
    void testDeleteLease_NotFound() {
        // Arrange
        Long leaseId = 999L;
        
        when(leaseService.findById(leaseId)).thenThrow(
            new ResourceNotFoundException("Lease with ID " + leaseId + " not found.")
        );

        // Act & Assert
        assertThrows(ResourceNotFoundException.class, () -> {
            leaseController.deleteLease(leaseId);
        });
    }

    @Test
    void testGetTenantsByLease_Success() {
        // Arrange
        Long tenantId = 1L;
        List<Lease> leases = Arrays.asList(
            createSampleLease(1L, tenantId, 100L),
            createSampleLease(2L, tenantId, 200L)
        );
        
        when(leaseService.findByTenantId(tenantId)).thenReturn(leases);

        // Act
        List<Lease> result = leaseController.getTenantsByLeaae(tenantId);

        // Assert
        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(lease -> lease.getTenantId().equals(tenantId)));
        verify(leaseService, times(1)).findByTenantId(tenantId);
    }

    @Test
    void testGetTenantsByLease_NoLeases() {
        // Arrange
        Long tenantId = 999L;
        
        when(leaseService.findByTenantId(tenantId)).thenReturn(Arrays.asList());

        // Act
        List<Lease> result = leaseController.getTenantsByLeaae(tenantId);

        // Assert
        assertTrue(result.isEmpty());
        verify(leaseService, times(1)).findByTenantId(tenantId);
    }
}