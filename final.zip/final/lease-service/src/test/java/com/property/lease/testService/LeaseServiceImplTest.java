package com.property.lease.testService;
 
import com.property.lease.Service.LeaseServiceImpl;
import com.property.lease.entity.Lease;
import com.property.lease.exception.ResourceNotFoundException;
import com.property.lease.repository.LeaseRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
class LeaseServiceImplTest {
 
    @InjectMocks
    private LeaseServiceImpl leaseService;
 
    @Mock
    private LeaseRepository leaseRepository;
 
    private Lease lease1, lease2;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);  
 
        lease1 = new Lease();
        lease1.setId(1L);
        lease1.setTenantId(5L);
        lease1.setPropertyId(101L);
        lease1.setStartDate(LocalDate.of(2023, 1, 1));
        lease1.setEndDate(LocalDate.of(2024, 1, 1));
        lease1.setMonthlyRent(1000);
 
        lease2 = new Lease();
        lease2.setId(2L);
        lease2.setTenantId(8L);
        lease2.setPropertyId(102L);
        lease2.setStartDate(LocalDate.of(2023, 2, 1));
        lease2.setEndDate(LocalDate.of(2024, 2, 1));
        lease2.setMonthlyRent(1200);
    }
 
    @Test
    void testSaveLease() {
        when(leaseRepository.save(lease1)).thenReturn(lease1);
        String result = leaseService.save(lease1);
        assertNotNull(result);
        assertEquals("Lease details added", result);
        verify(leaseRepository).save(lease1);
    }
 
    @Test
    void testFindById() {
        when(leaseRepository.findById(1L)).thenReturn(Optional.of(lease1));
        Lease result = leaseService.findById(1L);
        assertNotNull(result);
        assertEquals(lease1.getId(), result.getId());
    }
 
    @Test
    void testFindByIdNotFound() {
        when(leaseRepository.findById(99L)).thenReturn(Optional.empty());
        ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
            leaseService.findById(99L);
        });
        assertEquals("Lease with ID 99 not found.", thrown.getMessage());
    }
 
    @Test
    void testFindAllLeases() {
        when(leaseRepository.findAll()).thenReturn(Arrays.asList(lease1, lease2));
        List<Lease> result = leaseService.findAll();
        assertEquals(2, result.size());
    }
 
    @Test
    void testDeleteLeaseById() {
        doNothing().when(leaseRepository).deleteById(1L);
        leaseService.deleteById(1L);
        verify(leaseRepository).deleteById(1L);
    }
 
    @Test
    void testFindByTenantId() {
        when(leaseRepository.findByTenantId(5L)).thenReturn(Arrays.asList(lease1));
        List<Lease> result = leaseService.findByTenantId(5L);
        assertEquals(1, result.size());
        assertEquals(5L, result.get(0).getTenantId());
    }
}