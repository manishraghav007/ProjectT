package com.property.manager.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.ArrayList;
import java.util.List;

@Entity
public class Manager {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Manager name cannot be blank")
    @NotNull(message = "Manager name is required")
    private String name;

    private Long adminId;
    public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	// Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Transient
    private List<Long> tenantId = new ArrayList<>();
	public List<Long> getTenantId() {
		return tenantId;
	}

	public void setTenantId(List<Long> tenantId) {
		this.tenantId = tenantId;
	}
    

}
