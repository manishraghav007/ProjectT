package com.property.manager.service;

import java.util.List;

import com.property.manager.entity.Manager;

public interface ManagerServiceIntf {
	Manager save(Manager manager);

	List<Manager> getAllManagers();

	Manager findById(Long id);

	boolean deleteById(Long id);

	boolean existsById(Long id);

	List<Manager> findAllByAdminId(long adminId);
}
