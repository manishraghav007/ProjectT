package com.manager.controllertest;

import com.property.manager.controller.ManagerController;
import com.property.manager.entity.Manager;
import com.property.manager.service.ManagerServiceImpl;
import com.property.tenant.entity.Tenant;
import com.property.manager.exception.ResourceNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ManagerControllerTest {

	@Mock
	private ManagerServiceImpl managerService;

	@InjectMocks
	private ManagerController managerController;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	// Helper method to create a sample Manager
	private Manager createSampleManager(Long id, String name, Long adminId) {
		Manager manager = new Manager();
		manager.setId(id);
		manager.setName(name);
		manager.setAdminId(adminId);
		return manager;
	}

	@Test
	void testCreateManager_Success() {
		// Arrange
		Manager manager = createSampleManager(null, "John Doe", 1L);
		Manager savedManager = createSampleManager(1L, "John Doe", 1L);

		when(managerService.save(manager)).thenReturn(savedManager);

		// Act
		ResponseEntity<Manager> response = managerController.createManager(manager);

		// Assert
		assertEquals(HttpStatus.CREATED, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals(1L, response.getBody().getId());
		verify(managerService, times(1)).save(manager);
	}

	@Test
	void testGetAllManagers_Success() {
		// Arrange
		List<Manager> managers = Arrays.asList(createSampleManager(1L, "John Doe", 1L),
				createSampleManager(2L, "Jane Smith", 2L));

		when(managerService.getAllManagers()).thenReturn(managers);

		// Act
		List<Manager> result = managerController.getAllManagers();

		// Assert
		assertEquals(2, result.size());
		verify(managerService, times(1)).getAllManagers();
	}

	@Test
	void testGetManagerById_Success() {
		// Arrange
		Long managerId = 1L;
		Manager manager = createSampleManager(managerId, "John Doe", 1L);

		when(managerService.findById(managerId)).thenReturn(manager);

		// Act
		ResponseEntity<Manager> response = managerController.getManagerById(managerId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertNotNull(response.getBody());
		assertEquals(managerId, response.getBody().getId());
		verify(managerService, times(1)).findById(managerId);
	}

	@Test
	void testGetManagerById_NotFound() {
		// Arrange
		Long managerId = 999L;

		when(managerService.findById(managerId))
				.thenThrow(new ResourceNotFoundException("Manager with ID " + managerId + " not found."));

		// Act
		ResponseEntity<Manager> response = managerController.getManagerById(managerId);

		// Assert
		assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
		assertNull(response.getBody());
	}

	@Test
	void testDeleteManagerById_Success() {
		// Arrange
		Long managerId = 1L;

		when(managerService.deleteById(managerId)).thenReturn(true);

		// Act
		ResponseEntity<String> response = managerController.deleteManagerById(managerId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatusCode());
		assertEquals("Record of ID " + managerId + " is deleted.", response.getBody());
		verify(managerService, times(1)).deleteById(managerId);
	}

	@Test
	void testDeleteManagerById_Failure() {
		Long managerId = 999L;

		when(managerService.deleteById(managerId)).thenThrow(new ResourceNotFoundException("Manager not found"));

		ResponseEntity<String> response = managerController.deleteManagerById(managerId);

		assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
		assertEquals("Deletion failed.", response.getBody());
	}

	@Test
	void testFindAllByAdminId_Success() {
		// Arrange
		Long adminId = 1L;
		List<Manager> managers = Arrays.asList(createSampleManager(1L, "John Doe", adminId),
				createSampleManager(2L, "Jane Smith", adminId));

		when(managerService.findAllByAdminId(adminId)).thenReturn(managers);

		// Act
		List<Manager> result = managerController.findAllByAdminId(adminId);

		// Assert
		assertEquals(2, result.size());
		verify(managerService, times(1)).findAllByAdminId(adminId);
	}

	@Test
	void testAddTenantToManager_Success() {
		// Arrange
		Long managerId = 1L;
		Manager manager = createSampleManager(managerId, "John Doe", 1L);

		Tenant tenant = new Tenant();
		tenant.setId(100L);

		when(managerService.findById(managerId)).thenReturn(manager);
		when(managerService.save(manager)).thenReturn(manager);

		// Act
		String result = managerController.addTenanttoManager(managerId, tenant);

		// Assert
		assertEquals("Property successfully added to admin!", result);
		assertTrue(manager.getTenantId().contains(tenant.getId()));
		verify(managerService, times(1)).findById(managerId);
		verify(managerService, times(1)).save(manager);
	}

	@Test
	void testAddTenantToManager_Failure() {
		// Arrange
		Long managerId = 999L;

		Tenant tenant = new Tenant();
		tenant.setId(100L);

		when(managerService.findById(managerId)).thenThrow(new ResourceNotFoundException("Manager not found"));

		// Act
		String result = managerController.addTenanttoManager(managerId, tenant);

		// Assert
		assertTrue(result.startsWith("Error:"));
		verify(managerService, times(1)).findById(managerId);
	}
}