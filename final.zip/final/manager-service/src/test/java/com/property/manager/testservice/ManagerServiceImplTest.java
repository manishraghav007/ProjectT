package com.property.manager.testservice;
 
import com.property.manager.entity.Manager;
import com.property.manager.exception.ResourceNotFoundException;
import com.property.manager.repository.ManagerRepository;
import com.property.manager.service.ManagerServiceImpl;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
 
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
 
import java.util.Arrays;
import java.util.Optional;
 
@ExtendWith(MockitoExtension.class)
class ManagerServiceImplTest {
 
	@InjectMocks
	private ManagerServiceImpl managerService;
 
	@Mock
	private ManagerRepository managerRepository;
 
	private Manager manager;
 
	@BeforeEach
	void setUp() {
 
		manager = new Manager();
		manager.setId(1L);
		manager.setName("Manish Raghav");
		manager.setAdminId(100L);
	}
 
	@Test
	void testSaveManager() {
		when(managerRepository.save(manager)).thenReturn(manager);
 
		Manager result = managerService.save(manager);
 
		assertNotNull(result);
		assertEquals("Manish Raghav", result.getName());
		verify(managerRepository).save(manager);
	}
 
	@Test
	void testGetAllManagers() {
		when(managerRepository.findAll()).thenReturn(Arrays.asList(manager));
 
		var result = managerService.getAllManagers();
 
		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("Manish Raghav", result.get(0).getName());
	}
 
	@Test
	void testFindById() {
		when(managerRepository.findById(1L)).thenReturn(Optional.of(manager));
 
		Manager result = managerService.findById(1L);
 
		assertNotNull(result);
		assertEquals(manager.getName(), result.getName());
	}
 
	@Test
	void testFindByIdNotFound() {
		when(managerRepository.findById(99L)).thenReturn(Optional.empty());
 
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
			managerService.findById(99L);
		});
 
		assertEquals("Manager with ID 99 not found.", thrown.getMessage());
	}
 
	@Test
	void testDeleteById() {
		when(managerRepository.existsById(1L)).thenReturn(true);
		doNothing().when(managerRepository).deleteById(1L);
 
		boolean result = managerService.deleteById(1L);
 
		assertTrue(result);
		verify(managerRepository).deleteById(1L);
	}
 
	@Test
	void testDeleteByIdNotFound() {
		when(managerRepository.existsById(99L)).thenReturn(false);
 
		ResourceNotFoundException thrown = assertThrows(ResourceNotFoundException.class, () -> {
			managerService.deleteById(99L);
		});
 
		assertEquals("Manager with ID 99 not found.", thrown.getMessage());
	}
 
	@Test
	void testExistsById() {
		when(managerRepository.existsById(1L)).thenReturn(true);
 
		boolean result = managerService.existsById(1L);
 
		assertTrue(result);
	}
 
	@Test
	void testFindAllByAdminId() {
		when(managerRepository.findAllByAdminId(100L)).thenReturn(Arrays.asList(manager));
 
		var result = managerService.findAllByAdminId(100L);
 
		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals("Manish Raghav", result.get(0).getName());
	}
}