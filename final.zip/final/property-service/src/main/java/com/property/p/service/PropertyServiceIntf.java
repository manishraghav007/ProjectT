package com.property.p.service;

import java.util.List;
import java.util.Optional;

import com.property.p.entity.Property;

public interface PropertyServiceIntf {

	Property save(Property property);
	List<Property> getCity(String city);
	Optional<Property> findByid(Long id);
	List<Property> getAll();
	String updateProperty(Property property);
	List<Property> findByRent(double rent);
	void deleteById(Long id);
	boolean existsById(Long id);
	List<Property> getAllPropertiesByManagerId(long managerId);
}