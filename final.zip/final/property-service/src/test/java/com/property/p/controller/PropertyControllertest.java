package com.property.p.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.property.manager.exception.ResourceNotFoundException;
import com.property.p.controller.PropertyController;
import com.property.p.entity.Property;
import com.property.p.service.PropertyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class PropertyControllertest {

    @Mock
    private PropertyServiceImpl propertyService;

    @InjectMocks
    private PropertyController propertyController;

    private Property property;

    @BeforeEach
    public void setUp() {
        property = new Property();
        property.setId(1L);
        property.setName("Test Property");
        property.setCity("Test City");
        property.setAddress("123 Test Street");
        property.setRent(1000.0);
        property.setManagerId(10L);
    }

    @Test
    public void testAddProperty_Success() {
        when(propertyService.save(property)).thenReturn(property);

        ResponseEntity<Property> response = propertyController.addProperty(property);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(property, response.getBody());
        verify(propertyService).save(property);
    }

    @Test
    public void testAddProperty_Failure() {
        when(propertyService.save(property)).thenThrow(new RuntimeException("Save failed"));

        ResponseEntity<Property> response = propertyController.addProperty(property);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNull(response.getBody());
    }

    @Test
    public void testGetPropertiesByCity_Success() {
        List<Property> properties = new ArrayList<>();
        properties.add(property);

        when(propertyService.getCity("Test City")).thenReturn(properties);

        ResponseEntity<List<Property>> response = propertyController.getPropertiesByCity("Test City");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(properties, response.getBody());
    }

    @Test
    public void testGetPropertiesByCity_NotFound() {
        when(propertyService.getCity("Nonexistent City")).thenReturn(new ArrayList<>());

        assertThrows(ResourceNotFoundException.class, () -> {
            propertyController.getPropertiesByCity("Nonexistent City");
        });
    }

    @Test
    public void testGetAllProperties() {
        List<Property> properties = new ArrayList<>();
        properties.add(property);

        when(propertyService.getAll()).thenReturn(properties);

        List<Property> result = propertyController.getAllProperties();

        assertEquals(properties, result);
        verify(propertyService).getAll();
    }

    @Test
    public void testUpdateProperty_Success() {
        when(propertyService.existsById(property.getId())).thenReturn(true);
        when(propertyService.updateProperty(property)).thenReturn("Property updated successfully!");

        ResponseEntity<String> response = propertyController.updateProperty(property);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Property updated successfully!", response.getBody());
    }

    @Test
    public void testUpdateProperty_NotFound() {
        when(propertyService.existsById(property.getId())).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> {
            propertyController.updateProperty(property);
        });
    }

    @Test
    public void testGetPropertiesByRent_Success() {
        List<Property> properties = new ArrayList<>();
        properties.add(property);

        when(propertyService.findByRent(1000.0)).thenReturn(properties);

        List<Property> result = propertyController.getPropertiesByRent(1000.0);

        assertEquals(properties, result);
    }

    @Test
    public void testGetPropertiesByRent_NotFound() {
        when(propertyService.findByRent(9999.0)).thenReturn(new ArrayList<>());

        assertThrows(ResourceNotFoundException.class, () -> {
            propertyController.getPropertiesByRent(9999.0);
        });
    }

    @Test
    public void testDeleteProperty_Success() {
        when(propertyService.existsById(1L)).thenReturn(true);
        doNothing().when(propertyService).deleteById(1L);

        ResponseEntity<String> response = propertyController.deleteProperty(1L);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertEquals("Property with ID 1 has been successfully deleted.", response.getBody());
        verify(propertyService).deleteById(1L);
    }

    @Test
    public void testDeleteProperty_NotFound() {
        when(propertyService.existsById(1L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> {
            propertyController.deleteProperty(1L);
        });
    }

    @Test
    public void testGetAllByManagerId() {
        List<Property> properties = new ArrayList<>();
        properties.add(property);

        when(propertyService.getAllPropertiesByManagerId(10L)).thenReturn(properties);

        List<Property> result = propertyController.getAllByManagerId(10L);

        assertEquals(properties, result);
        verify(propertyService).getAllPropertiesByManagerId(10L);
    }

    @Test
    public void testGetPropertyById_Success() {
        when(propertyService.findByid(1L)).thenReturn(Optional.of(property));

        Property result = propertyController.getPropertyById(1L);

        assertEquals(property, result);
    }

    @Test
    public void testGetPropertyById_NotFound() {
        when(propertyService.findByid(1L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            propertyController.getPropertyById(1L);
        });
    }

    @Test
    public void testGetPropertiesByAdminId() {
        List<Property> properties = new ArrayList<>();
        properties.add(property);

        when(propertyService.getAllPropertiesByManagerId(10L)).thenReturn(properties);

        List<Property> result = propertyController.getPropertiesByAdminId(10L);

        assertEquals(properties, result);
        verify(propertyService).getAllPropertiesByManagerId(10L);
    }
}