package com.property.p.testservice;
 
import com.property.p.entity.Property;
import com.property.p.repository.PropertyRepository;
import com.property.p.service.PropertyServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
 
import java.util.Arrays;
import java.util.List;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
@ExtendWith(MockitoExtension.class)
public class PropertyServiceImplTest {
 
	@Mock
	private PropertyRepository propertyRepository;
 
	@InjectMocks
	private PropertyServiceImpl propertyService;
 
	private Property testProperty;
 
	@BeforeEach
	void setUp() {
		testProperty = new Property();
		testProperty.setId(1L);
		testProperty.setName("Test Property");
		testProperty.setCity("Test City");
		testProperty.setAddress("123 Test St");
		testProperty.setRent(1000);
		testProperty.setManagerId(1L);
	}
 
	@Test
	void shouldSavePropertySuccessfully() {
		when(propertyRepository.save(testProperty)).thenReturn(testProperty);
 
		Property savedProperty = propertyService.save(testProperty);
 
		assertNotNull(savedProperty);
		assertEquals("Test Property", savedProperty.getName());
 
		verify(propertyRepository, times(1)).save(testProperty);
	}
 
	@Test
	void shouldReturnAllProperties() {
		when(propertyRepository.findAll()).thenReturn(Arrays.asList(testProperty));
 
		List<Property> properties = propertyService.getAll();
 
		assertNotNull(properties);
		assertFalse(properties.isEmpty());
		assertEquals(1, properties.size());
		assertEquals("Test Property", properties.get(0).getName());
 
		verify(propertyRepository, times(1)).findAll();
	}
 
	@Test
	void shouldReturnPropertiesByCity() {
		when(propertyRepository.findByCity("Test City")).thenReturn(Arrays.asList(testProperty));
 
		List<Property> properties = propertyService.getCity("Test City");
 
		assertNotNull(properties);
		assertFalse(properties.isEmpty());
		assertEquals("Test City", properties.get(0).getCity());
 
		verify(propertyRepository, times(1)).findByCity("Test City");
	}
 
	@Test
	void shouldUpdatePropertySuccessfully() {
		when(propertyRepository.save(testProperty)).thenReturn(testProperty);
 
		String result = propertyService.updateProperty(testProperty);
 
		assertEquals("Property updated successfully!", result);
		verify(propertyRepository, times(1)).save(testProperty);
	}
 
	@Test
	void shouldReturnPropertiesByRent() {
		when(propertyRepository.findByRent(1000)).thenReturn(Arrays.asList(testProperty));
 
		List<Property> properties = propertyService.findByRent(1000);
 
		assertNotNull(properties);
		assertFalse(properties.isEmpty());
		assertEquals(1000, properties.get(0).getRent());
 
		verify(propertyRepository, times(1)).findByRent(1000);
	}
 
	@Test
	void shouldDeletePropertyById() {
		doNothing().when(propertyRepository).deleteById(1L);
 
		propertyService.deleteById(1L);
 
		verify(propertyRepository, times(1)).deleteById(1L);
	}
 
	@Test
	void shouldCheckIfPropertyExistsById() {
		when(propertyRepository.existsById(1L)).thenReturn(true);
 
		boolean exists = propertyService.existsById(1L);
 
		assertTrue(exists);
 
		verify(propertyRepository, times(1)).existsById(1L);
	}
 
	@Test
	void shouldReturnPropertiesByManagerId() {
		when(propertyRepository.findAllByManagerId(1L)).thenReturn(Arrays.asList(testProperty));
 
		List<Property> properties = propertyService.getAllPropertiesByManagerId(1L);
 
		assertNotNull(properties);
		assertFalse(properties.isEmpty());
		assertEquals(1L, properties.get(0).getManagerId());
 
		verify(propertyRepository, times(1)).findAllByManagerId(1L);
	}
}