package com.property.tenant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.property.complaint.entity.Complaint;
import com.property.tenant.entity.Tenant;
import com.property.tenant.exception.ResourceNotFoundException;
import com.property.tenant.service.TenantServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/tenant")
@Validated
public class TenantController {
	
	@Autowired
	private TenantServiceImpl tenantService;
	
	@PostMapping("/add")
	public ResponseEntity<String> save(@RequestBody @Valid Tenant tenant) {
		 try {
	            String response = tenantService.save(tenant);
	            return ResponseEntity.status(HttpStatus.CREATED).body(response);
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Validation failed: " + e.getMessage());
	        }
	}
	
	 @GetMapping("/getById/{id}")
	   public Tenant getTenantById(@PathVariable long id) {
		   return tenantService.findById(id);
	    }
	    
	@GetMapping("/getall")
	public List<Tenant> getAll(){
		return tenantService.getAll();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteTenant(@PathVariable Long id) {
		 if (!tenantService.existsById(id)) {
	            throw new ResourceNotFoundException("Tenant id" + id + " not found");
	        }
	        tenantService.deleteTenant(id);
	        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Tenant deleted");
	    }
	 @GetMapping("/getallbyproperty/{propertyId}")
	   public List<Tenant> getAllByPropertyId(@PathVariable Long propertyId){
		   return tenantService.findByPropertyId(propertyId);
	   }
	 
	 @PostMapping("/{tenantId}/addComplaint")
		public String addComplaintTotenant(@PathVariable Long tenantId, @RequestBody Complaint complaint) {
			try {
				Tenant tenant = tenantService.findById(tenantId);
				tenant.getComplaintId().add(complaint.getId());
				tenantService.save(tenant);
				return "Complaint successfully added to Tenant!";
			} catch (Exception e) {
				e.printStackTrace();
				return "Error" + e.getMessage();
			}	
		}
}
