package com.property.tenant.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class Tenant {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@NotBlank(message = "Tenant name cannot be blank")
	@Size(max = 100, message = "Tenant name must be at most 100 characters")
	private String name;

	@NotBlank(message = "Email cannot be blank")
	@Email(message = "Invalid email format")
	private String email;
	@NotNull(message = "Phone number cannot be null")
	@Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
	private String Phone;
	
	private Long propertyId;
	private Long managerId;

	@Transient
    private List<Long> ComplaintId = new ArrayList<>();

	public List<Long> getComplaintId() {
		return ComplaintId;
	}

	public void setComplaintId(List<Long> leaseId) {
		ComplaintId = leaseId;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return Phone;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}

	

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	
	public Long getManagerId() {
		return managerId;
	}

	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}

	public Tenant() {
		super();
	}

	public Tenant(long id,
			@NotBlank(message = "Tenant name cannot be blank") @Size(max = 100, message = "Tenant name must be at most 100 characters") String name,
			@NotBlank(message = "Email cannot be blank") @Email(message = "Invalid email format") String email,
			@NotNull(message = "Phone number cannot be null") @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits") String phone,
			Long propertyId,Long managerId) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		Phone = phone;
		this.propertyId = propertyId;
		this.managerId=managerId;
	}
	

}
