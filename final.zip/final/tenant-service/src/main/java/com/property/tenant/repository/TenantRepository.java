package com.property.tenant.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.property.tenant.entity.Tenant;

public interface TenantRepository extends JpaRepository<Tenant, Long>{

	  List<Tenant> findByPropertyId(Long propertyId);
	  List<Tenant> findByManagerId(Long managerId);
	  
}
