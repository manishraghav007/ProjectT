package com.property.tenant.service;

import java.util.List;

import com.property.tenant.entity.Tenant;

public interface TenantServiceIntf {
	String save(Tenant tenant);

	List<Tenant> getAll();
	Tenant findById(Long id);

	void deleteTenant(Long id);

	boolean existsById(Long id);
	
	List<Tenant> findByPropertyId(Long propertyId);
	 List<Tenant> findByManagerId(Long managerId);
}
