package com.property.tenant.testservice;

import com.property.tenant.entity.Tenant;
import com.property.tenant.repository.TenantRepository;
import com.property.tenant.service.TenantServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TenantServiceImplTest {

    @InjectMocks
    private TenantServiceImpl tenantService;

    @Mock
    private TenantRepository tenantRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveTenant() {
        Tenant tenant = new Tenant(1L, "Manish Raghav", "manish.raghav@example.com", "9876543210", 101L, 1L);
        when(tenantRepository.save(tenant)).thenReturn(tenant);

        String result = tenantService.save(tenant);

        assertEquals("Tenant details added successfully", result);
        verify(tenantRepository, times(1)).save(tenant);
    }

    @Test
    void testGetAllTenants() {
        List<Tenant> tenants = Arrays.asList(
            new Tenant(1L, "Manish Raghav", "manish.raghav@example.com", "9876543210", 101L, 1L),
            new Tenant(2L, "Abhishek Kumar", "abhishek.kumar@example.com", "8765432109", 102L, 2L)
        );
        when(tenantRepository.findAll()).thenReturn(tenants);

        List<Tenant> result = tenantService.getAll();

        assertNotNull(result);
        assertEquals(2, result.size());
        verify(tenantRepository, times(1)).findAll();
    }

    @Test
    void testGetAllTenantsEmptyList() {
        when(tenantRepository.findAll()).thenReturn(Arrays.asList());

        List<Tenant> result = tenantService.getAll();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(tenantRepository, times(1)).findAll();
    }

    @Test
    void testFindTenantById() {
        Tenant tenant = new Tenant(1L, "Manish Raghav", "manish.raghav@example.com", "9876543210", 101L, 1L);
        when(tenantRepository.findById(1L)).thenReturn(Optional.of(tenant));

        Tenant result = tenantService.findById(1L);

        assertNotNull(result);
        assertEquals("Manish Raghav", result.getName());
        verify(tenantRepository, times(1)).findById(1L);
    }

    @Test
    void testFindTenantByIdNotFound() {
        when(tenantRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> tenantService.findById(1L));
        assertEquals("Manager with ID 1 not found.", exception.getMessage());
        verify(tenantRepository, times(1)).findById(1L);
    }

    @Test
    void testDeleteTenantById() {
        when(tenantRepository.existsById(1L)).thenReturn(true);

        tenantService.deleteTenant(1L);

        verify(tenantRepository, times(1)).deleteById(1L);
    }

    @Test
    void testExistsByIdTrue() {
        when(tenantRepository.existsById(1L)).thenReturn(true);

        boolean exists = tenantService.existsById(1L);

        assertTrue(exists);
        verify(tenantRepository, times(1)).existsById(1L);
    }

    @Test
    void testExistsByIdFalse() {
        when(tenantRepository.existsById(1L)).thenReturn(false);

        boolean exists = tenantService.existsById(1L);

        assertFalse(exists);
        verify(tenantRepository, times(1)).existsById(1L);
    }
}
