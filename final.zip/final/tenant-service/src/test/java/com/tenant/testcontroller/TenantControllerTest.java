package com.tenant.testcontroller;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.property.complaint.entity.Complaint;
import com.property.tenant.controller.TenantController;
import com.property.tenant.entity.Tenant;
import com.property.tenant.exception.ResourceNotFoundException;
import com.property.tenant.service.TenantServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
public class TenantControllerTest {

    @Mock
    private TenantServiceImpl tenantService;

    @InjectMocks
    private TenantController tenantController;

    private Tenant tenant;

    @BeforeEach
    public void setUp() {
        tenant = new Tenant();
        tenant.setId(1L);
        tenant.setName("John Doe");
        tenant.setEmail("john.doe@example.com");
        tenant.setPhone("1234567890");
        tenant.setPropertyId(101L);
        tenant.setManagerId(201L);
    }

    @Test
    public void testSaveTenant_Success() {
        when(tenantService.save(tenant)).thenReturn("Tenant details added successfully");

        ResponseEntity<String> response = tenantController.save(tenant);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Tenant details added successfully", response.getBody());
        verify(tenantService).save(tenant);
    }

    @Test
    public void testSaveTenant_Failure() {
        when(tenantService.save(tenant)).thenThrow(new RuntimeException("Validation error"));

        ResponseEntity<String> response = tenantController.save(tenant);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertTrue(response.getBody().contains("Validation failed"));
    }

    @Test
    public void testGetTenantById_Success() {
        when(tenantService.findById(1L)).thenReturn(tenant);

        Tenant result = tenantController.getTenantById(1L);

        assertEquals(tenant, result);
        verify(tenantService).findById(1L);
    }

    @Test
    public void testGetTenantById_NotFound() {
        when(tenantService.findById(1L)).thenThrow(new RuntimeException("Tenant not found"));

        assertThrows(RuntimeException.class, () -> {
            tenantController.getTenantById(1L);
        });
    }

    @Test
    public void testGetAllTenants() {
        List<Tenant> tenants = new ArrayList<>();
        tenants.add(tenant);

        when(tenantService.getAll()).thenReturn(tenants);

        List<Tenant> result = tenantController.getAll();

        assertEquals(tenants, result);
        verify(tenantService).getAll();
    }

    @Test
    public void testDeleteTenant_Success() {
        when(tenantService.existsById(1L)).thenReturn(true);
        doNothing().when(tenantService).deleteTenant(1L);

        ResponseEntity<String> response = tenantController.deleteTenant(1L);

        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertEquals("Tenant deleted", response.getBody());
        verify(tenantService).deleteTenant(1L);
    }

    @Test
    public void testDeleteTenant_NotFound() {
        when(tenantService.existsById(1L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> {
            tenantController.deleteTenant(1L);
        });
    }

    @Test
    public void testGetAllByPropertyId() {
        List<Tenant> tenants = new ArrayList<>();
        tenants.add(tenant);

        when(tenantService.findByPropertyId(101L)).thenReturn(tenants);

        List<Tenant> result = tenantController.getAllByPropertyId(101L);

        assertEquals(tenants, result);
        verify(tenantService).findByPropertyId(101L);
    }

    @Test
    public void testAddComplaintToTenant_Success() {
        Complaint complaint = new Complaint();
        complaint.setId(1L);

        when(tenantService.findById(1L)).thenReturn(tenant);
        when(tenantService.save(tenant)).thenReturn("Tenant updated");

        String result = tenantController.addComplaintTotenant(1L, complaint);

        assertEquals("Complaint successfully added to Tenant!", result);
        assertTrue(tenant.getComplaintId().contains(1L));
        verify(tenantService).findById(1L);
        verify(tenantService).save(tenant);
    }

    @Test
    public void testAddComplaintToTenant_Failure() {
        Complaint complaint = new Complaint();
        complaint.setId(1L);

        when(tenantService.findById(1L)).thenThrow(new RuntimeException("Tenant not found"));

        String result = tenantController.addComplaintTotenant(1L, complaint);

        assertTrue(result.startsWith("Error"));
    }
}